import nodemailer from "nodemailer"
import { render } from "@react-email/render"
import BookingConfirmationEmail from "@/emails/booking-confirmation"
import PaymentReceiptEmail from "@/emails/payment-receipt"
import BookingReminderEmail from "@/emails/booking-reminder"
import WarehouseAlertEmail from "@/emails/warehouse-alert"

// Create a transporter using environment variables
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_SERVER_HOST,
  port: Number(process.env.EMAIL_SERVER_PORT || "587"),
  auth: {
    user: process.env.EMAIL_SERVER_USER,
    pass: process.env.EMAIL_SERVER_PASSWORD,
  },
  secure: process.env.EMAIL_SERVER_PORT === "465",
})

// Verify the transporter connection
transporter.verify().catch((error) => {
  console.error("Email transporter verification failed:", error)
})

export type BookingDetails = {
  bookingId: string
  warehouseName: string
  startDate: Date
  endDate: Date
  amount: number
  orderId: string
}

export async function sendBookingConfirmation(email: string, name: string, bookingDetails: BookingDetails) {
  try {
    const emailHtml = render(
      BookingConfirmationEmail({
        name,
        bookingDetails,
      }),
    )

    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: email,
      subject: "Booking Confirmation - Stockware",
      html: emailHtml,
    })

    return { success: true }
  } catch (error) {
    console.error("Failed to send booking confirmation email:", error)
    return { success: false, error }
  }
}

export async function sendPaymentReceipt(email: string, name: string, bookingDetails: BookingDetails) {
  try {
    const emailHtml = render(
      PaymentReceiptEmail({
        name,
        bookingDetails,
      }),
    )

    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: email,
      subject: "Payment Receipt - Stockware",
      html: emailHtml,
    })

    return { success: true }
  } catch (error) {
    console.error("Failed to send payment receipt email:", error)
    return { success: false, error }
  }
}

export async function sendBookingReminder(email: string, name: string, bookingDetails: BookingDetails) {
  try {
    const emailHtml = render(
      BookingReminderEmail({
        name,
        bookingDetails,
      }),
    )

    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: email,
      subject: "Booking Reminder - Stockware",
      html: emailHtml,
    })

    return { success: true }
  } catch (error) {
    console.error("Failed to send booking reminder email:", error)
    return { success: false, error }
  }
}

export async function sendWarehouseAlert(
  email: string,
  name: string,
  alertDetails: {
    warehouseName: string
    alertType: "occupancy" | "security" | "maintenance"
    message: string
  },
) {
  try {
    const emailHtml = render(
      WarehouseAlertEmail({
        name,
        alertDetails,
      }),
    )

    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: email,
      subject: `Warehouse Alert: ${alertDetails.alertType.toUpperCase()} - Stockware`,
      html: emailHtml,
    })

    return { success: true }
  } catch (error) {
    console.error("Failed to send warehouse alert email:", error)
    return { success: false, error }
  }
}

