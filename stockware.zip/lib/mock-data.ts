// Mock warehouse data
export const warehouses = [
  {
    id: "1",
    name: "Mega Storage Hub",
    location: "Mumbai, Maharashtra",
    type: "DRY_STORAGE",
    price: 25000,
    capacity: 5000,
    description:
      "A spacious dry storage warehouse with 24/7 security and easy highway access. Perfect for storing retail goods, furniture, and non-perishable items.",
    features: ["24/7 Security", "Loading Docks", "Inventory Management", "Fire Protection"],
    imageUrl: "/placeholder.svg?height=400&width=600",
    ownerName: "Rajesh Enterprises",
    createdAt: new Date("2023-01-15").toISOString(),
  },
  {
    id: "2",
    name: "Cool Keep Warehouse",
    location: "Delhi, NCR",
    type: "COLD_STORAGE",
    price: 30000,
    capacity: 3000,
    description:
      "State-of-the-art cold storage facility with temperature control from -20°C to +10°C. Ideal for perishable goods, pharmaceuticals, and food products.",
    features: ["Temperature Control", "Backup Generators", "24/7 Monitoring", "Inventory Tracking"],
    imageUrl: "/placeholder.svg?height=400&width=600",
    ownerName: "Sharma Cold Chain",
    createdAt: new Date("2023-02-20").toISOString(),
  },
  {
    id: "3",
    name: "Secure Vault Storage",
    location: "Bangalore, Karnataka",
    type: "HAZARDOUS_MATERIALS",
    price: 35000,
    capacity: 2000,
    description:
      "Specialized warehouse for hazardous materials with proper ventilation, containment systems, and regulatory compliance. Certified for chemical storage.",
    features: ["Hazmat Certification", "Spill Containment", "Ventilation Systems", "Regulatory Compliance"],
    imageUrl: "/placeholder.svg?height=400&width=600",
    ownerName: "SafeStore Solutions",
    createdAt: new Date("2023-03-10").toISOString(),
  },
  {
    id: "4",
    name: "Urban Mini Storage",
    location: "Pune, Maharashtra",
    type: "DRY_STORAGE",
    price: 18000,
    capacity: 1500,
    description:
      "Conveniently located mini storage facility in the heart of Pune. Flexible space options for businesses and individuals needing short-term storage.",
    features: ["Flexible Space", "Urban Location", "Short-term Rentals", "Easy Access"],
    imageUrl: "/placeholder.svg?height=400&width=600",
    ownerName: "City Storage Co.",
    createdAt: new Date("2023-04-05").toISOString(),
  },
  {
    id: "5",
    name: "Pharma Cold Chain",
    location: "Hyderabad, Telangana",
    type: "COLD_STORAGE",
    price: 40000,
    capacity: 2500,
    description:
      "Pharmaceutical-grade cold storage with validated temperature mapping and GMP compliance. Suitable for vaccines, biologics, and temperature-sensitive medications.",
    features: ["GMP Compliance", "Temperature Validation", "Backup Systems", "Pharmaceutical Grade"],
    imageUrl: "/placeholder.svg?height=400&width=600",
    ownerName: "MedStore Solutions",
    createdAt: new Date("2023-05-12").toISOString(),
  },
  {
    id: "6",
    name: "Logistics Hub Warehouse",
    location: "Chennai, Tamil Nadu",
    type: "DRY_STORAGE",
    price: 28000,
    capacity: 6000,
    description:
      "Large logistics warehouse with cross-docking facilities and proximity to Chennai port. Ideal for import-export businesses and distribution centers.",
    features: ["Cross-Docking", "Port Proximity", "High Ceiling", "Multiple Loading Bays"],
    imageUrl: "/placeholder.svg?height=400&width=600",
    ownerName: "Port Logistics Ltd.",
    createdAt: new Date("2023-06-18").toISOString(),
  },
]

// Mock booking data
export const bookings = [
  {
    id: "1",
    warehouseId: "1",
    userId: "user1",
    startDate: new Date("2023-10-01").toISOString(),
    endDate: new Date("2023-11-01").toISOString(),
    status: "CONFIRMED",
    totalPrice: 25000,
    days: 31,
    paymentId: "pay_123456",
    orderId: "order_123456",
    createdAt: new Date("2023-09-15").toISOString(),
  },
  {
    id: "2",
    warehouseId: "2",
    userId: "user1",
    startDate: new Date(Date.now() + 86400000 * 10).toISOString(), // 10 days from now
    endDate: new Date(Date.now() + 86400000 * 40).toISOString(), // 40 days from now
    status: "CONFIRMED",
    totalPrice: 30000,
    days: 30,
    paymentId: "pay_234567",
    orderId: "order_234567",
    createdAt: new Date("2023-09-20").toISOString(),
  },
  {
    id: "3",
    warehouseId: "3",
    userId: "user1",
    startDate: new Date(Date.now() - 86400000 * 15).toISOString(), // 15 days ago
    endDate: new Date(Date.now() + 86400000 * 15).toISOString(), // 15 days from now
    status: "CONFIRMED",
    totalPrice: 35000,
    days: 30,
    paymentId: "pay_345678",
    orderId: "order_345678",
    createdAt: new Date("2023-09-25").toISOString(),
  },
]

// Mock user data
export const users = [
  {
    id: "user1",
    name: "Demo User",
    email: "demo@example.com",
    role: "BUSINESS",
    image: null,
  },
  {
    id: "user2",
    name: "Warehouse Owner",
    email: "owner@example.com",
    role: "WAREHOUSE_OWNER",
    image: null,
  },
]

// Helper function to get warehouse by ID
export function getWarehouseById(id: string) {
  return warehouses.find((warehouse) => warehouse.id === id)
}

// Helper function to get bookings by user ID
export function getBookingsByUserId(userId: string) {
  return bookings
    .filter((booking) => booking.userId === userId)
    .map((booking) => ({
      ...booking,
      warehouse: getWarehouseById(booking.warehouseId),
    }))
}

// Helper function to get warehouses by owner ID
export function getWarehousesByOwnerId(ownerId: string) {
  return warehouses.filter((warehouse) => warehouse.ownerName === ownerId)
}

// Helper function to filter warehouses
export function filterWarehouses(filters: any = {}) {
  return warehouses.filter((warehouse) => {
    // Filter by location
    if (filters.location && !warehouse.location.toLowerCase().includes(filters.location.toLowerCase())) {
      return false
    }

    // Filter by type
    if (filters.type && filters.type !== "ALL" && warehouse.type !== filters.type) {
      return false
    }

    // Filter by price range
    if (filters.minPrice && warehouse.price < Number(filters.minPrice)) {
      return false
    }

    if (filters.maxPrice && warehouse.price > Number(filters.maxPrice)) {
      return false
    }

    // Filter by capacity
    if (filters.minCapacity && warehouse.capacity < Number(filters.minCapacity)) {
      return false
    }

    return true
  })
}

