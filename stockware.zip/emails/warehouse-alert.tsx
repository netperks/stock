interface WarehouseAlertEmailProps {
  name: string
  alertDetails: {
    warehouseName: string
    alertType: "occupancy" | "security" | "maintenance"
    message: string
  }
}

export default function WarehouseAlertEmail({ name, alertDetails }: WarehouseAlertEmailProps) {
  // Set alert-specific styles and content
  let alertColor = "#f5f5f5"
  let alertIcon = "⚠️"
  let alertTitle = "Alert"

  switch (alertDetails.alertType) {
    case "security":
      alertColor = "#ffebee"
      alertIcon = "🔒"
      alertTitle = "Security Alert"
      break
    case "occupancy":
      alertColor = "#e8f5e9"
      alertIcon = "📊"
      alertTitle = "Occupancy Alert"
      break
    case "maintenance":
      alertColor = "#fff8e1"
      alertIcon = "🔧"
      alertTitle = "Maintenance Alert"
      break
  }

  return (
    <div style={container}>
      <div style={header}>
        <h1 style={heading}>
          {alertIcon} {alertTitle}: {alertDetails.warehouseName}
        </h1>
      </div>
      <div style={body}>
        <p style={paragraph}>Dear {name},</p>
        <p style={paragraph}>
          We're sending this alert regarding your warehouse: <strong>{alertDetails.warehouseName}</strong>.
        </p>
        <div style={{ ...alertBox, backgroundColor: alertColor }}>
          <h2 style={subheading}>{alertTitle} Details:</h2>
          <p style={paragraph}>{alertDetails.message}</p>
        </div>
        <div style={buttonContainer}>
          <a href={`${process.env.NEXT_PUBLIC_URL}/dashboard/warehouses`} style={button}>
            View Warehouse Dashboard
          </a>
        </div>
        <p style={paragraph}>
          If you have any questions or need assistance, please contact our support team immediately.
        </p>
        <p style={paragraph}>
          Best regards,
          <br />
          Stockware Team
        </p>
      </div>
      <div style={footer}>
        <p style={footerText}>© {new Date().getFullYear()} Stockware. All rights reserved.</p>
        <p style={footerText}>123 Warehouse Street, Mumbai, India</p>
      </div>
    </div>
  )
}

// Styles
const container = {
  fontFamily: "Arial, sans-serif",
  maxWidth: "600px",
  margin: "0 auto",
  padding: "20px",
  border: "1px solid #e0e0e0",
  borderRadius: "5px",
}

const header = {
  textAlign: "center" as const,
  padding: "20px 0",
  borderBottom: "1px solid #e0e0e0",
}

const heading = {
  color: "#0C4A6E",
  margin: "0",
}

const body = {
  padding: "20px 0",
}

const paragraph = {
  lineHeight: "1.5",
  margin: "10px 0",
}

const alertBox = {
  padding: "15px",
  borderRadius: "5px",
  margin: "20px 0",
  border: "1px solid #e0e0e0",
}

const subheading = {
  marginTop: "0",
  color: "#0C4A6E",
}

const buttonContainer = {
  textAlign: "center" as const,
  margin: "30px 0",
}

const button = {
  backgroundColor: "#0C4A6E",
  color: "white",
  padding: "12px 24px",
  borderRadius: "5px",
  textDecoration: "none",
  fontWeight: "bold",
}

const footer = {
  borderTop: "1px solid #e0e0e0",
  padding: "20px 0",
  textAlign: "center" as const,
}

const footerText = {
  fontSize: "12px",
  color: "#666",
  margin: "5px 0",
}

