import type { BookingDetails } from "@/lib/email"

interface BookingReminderEmailProps {
  name: string
  bookingDetails: BookingDetails
}

export default function BookingReminderEmail({ name, bookingDetails }: BookingReminderEmailProps) {
  return (
    <div style={container}>
      <div style={header}>
        <h1 style={heading}>Your Booking Starts Tomorrow</h1>
      </div>
      <div style={body}>
        <p style={paragraph}>Dear {name},</p>
        <p style={paragraph}>
          This is a friendly reminder that your booking at <strong>{bookingDetails.warehouseName}</strong> starts
          tomorrow.
        </p>
        <div style={reminderBox}>
          <h2 style={subheading}>Booking Details:</h2>
          <ul style={list}>
            <li style={listItem}>
              <strong>Booking ID:</strong> {bookingDetails.bookingId}
            </li>
            <li style={listItem}>
              <strong>Start Date:</strong> {bookingDetails.startDate.toLocaleDateString()}
            </li>
            <li style={listItem}>
              <strong>End Date:</strong> {bookingDetails.endDate.toLocaleDateString()}
            </li>
            <li style={listItem}>
              <strong>Warehouse:</strong> {bookingDetails.warehouseName}
            </li>
          </ul>
        </div>
        <div style={infoBox}>
          <h3 style={infoHeading}>Important Information:</h3>
          <ul style={list}>
            <li style={listItem}>Please bring your booking confirmation or ID for verification.</li>
            <li style={listItem}>The warehouse is accessible from 8:00 AM to 8:00 PM.</li>
            <li style={listItem}>For after-hours access, please contact the warehouse manager.</li>
            <li style={listItem}>Safety equipment is required when entering the warehouse.</li>
          </ul>
        </div>
        <div style={buttonContainer}>
          <a href={`${process.env.NEXT_PUBLIC_URL}/dashboard/bookings/${bookingDetails.bookingId}`} style={button}>
            View Booking Details
          </a>
        </div>
        <p style={paragraph}>
          If you need to make any changes to your booking or have any questions, please contact us as soon as possible.
        </p>
        <p style={paragraph}>
          Best regards,
          <br />
          Stockware Team
        </p>
      </div>
      <div style={footer}>
        <p style={footerText}>© {new Date().getFullYear()} Stockware. All rights reserved.</p>
        <p style={footerText}>123 Warehouse Street, Mumbai, India</p>
      </div>
    </div>
  )
}

// Styles
const container = {
  fontFamily: "Arial, sans-serif",
  maxWidth: "600px",
  margin: "0 auto",
  padding: "20px",
  border: "1px solid #e0e0e0",
  borderRadius: "5px",
}

const header = {
  textAlign: "center" as const,
  padding: "20px 0",
  borderBottom: "1px solid #e0e0e0",
}

const heading = {
  color: "#0C4A6E",
  margin: "0",
}

const body = {
  padding: "20px 0",
}

const paragraph = {
  lineHeight: "1.5",
  margin: "10px 0",
}

const reminderBox = {
  backgroundColor: "#f5f5f5",
  padding: "15px",
  borderRadius: "5px",
  margin: "20px 0",
}

const infoBox = {
  backgroundColor: "#e6f7ff",
  padding: "15px",
  borderRadius: "5px",
  margin: "20px 0",
  border: "1px solid #91d5ff",
}

const subheading = {
  marginTop: "0",
  color: "#0C4A6E",
}

const infoHeading = {
  marginTop: "0",
  color: "#0C4A6E",
  fontSize: "16px",
}

const list = {
  listStyleType: "none",
  paddingLeft: "0",
}

const listItem = {
  margin: "10px 0",
}

const buttonContainer = {
  textAlign: "center" as const,
  margin: "30px 0",
}

const button = {
  backgroundColor: "#0C4A6E",
  color: "white",
  padding: "12px 24px",
  borderRadius: "5px",
  textDecoration: "none",
  fontWeight: "bold",
}

const footer = {
  borderTop: "1px solid #e0e0e0",
  padding: "20px 0",
  textAlign: "center" as const,
}

const footerText = {
  fontSize: "12px",
  color: "#666",
  margin: "5px 0",
}

