import type { BookingDetails } from "@/lib/email"

interface PaymentReceiptEmailProps {
  name: string
  bookingDetails: BookingDetails
}

export default function PaymentReceiptEmail({ name, bookingDetails }: PaymentReceiptEmailProps) {
  return (
    <div style={container}>
      <div style={header}>
        <h1 style={heading}>Payment Receipt</h1>
      </div>
      <div style={body}>
        <p style={paragraph}>Dear {name},</p>
        <p style={paragraph}>
          Thank you for your payment. This email serves as your official receipt for your booking at{" "}
          <strong>{bookingDetails.warehouseName}</strong>.
        </p>
        <div style={receiptBox}>
          <h2 style={subheading}>Payment Details:</h2>
          <table style={table}>
            <tbody>
              <tr>
                <td style={tableLabel}>Booking ID:</td>
                <td style={tableValue}>{bookingDetails.bookingId}</td>
              </tr>
              <tr>
                <td style={tableLabel}>Order ID:</td>
                <td style={tableValue}>{bookingDetails.orderId}</td>
              </tr>
              <tr>
                <td style={tableLabel}>Payment Date:</td>
                <td style={tableValue}>{new Date().toLocaleDateString()}</td>
              </tr>
              <tr>
                <td style={tableLabel}>Booking Period:</td>
                <td style={tableValue}>
                  {bookingDetails.startDate.toLocaleDateString()} to {bookingDetails.endDate.toLocaleDateString()}
                </td>
              </tr>
              <tr>
                <td style={tableLabel}>Amount Paid:</td>
                <td style={tableValue}>₹{bookingDetails.amount.toLocaleString()}</td>
              </tr>
              <tr>
                <td style={tableLabel}>Payment Status:</td>
                <td style={tableValue}>Completed</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div style={buttonContainer}>
          <a
            href={`${process.env.NEXT_PUBLIC_URL}/dashboard/bookings/${bookingDetails.bookingId}/invoice`}
            style={button}
          >
            Download Invoice
          </a>
        </div>
        <p style={paragraph}>
          If you have any questions about this payment or need further assistance, please contact our support team.
        </p>
        <p style={paragraph}>
          Best regards,
          <br />
          Stockware Team
        </p>
      </div>
      <div style={footer}>
        <p style={footerText}>© {new Date().getFullYear()} Stockware. All rights reserved.</p>
        <p style={footerText}>123 Warehouse Street, Mumbai, India</p>
      </div>
    </div>
  )
}

// Styles
const container = {
  fontFamily: "Arial, sans-serif",
  maxWidth: "600px",
  margin: "0 auto",
  padding: "20px",
  border: "1px solid #e0e0e0",
  borderRadius: "5px",
}

const header = {
  textAlign: "center" as const,
  padding: "20px 0",
  borderBottom: "1px solid #e0e0e0",
}

const heading = {
  color: "#0C4A6E",
  margin: "0",
}

const body = {
  padding: "20px 0",
}

const paragraph = {
  lineHeight: "1.5",
  margin: "10px 0",
}

const receiptBox = {
  backgroundColor: "#f5f5f5",
  padding: "15px",
  borderRadius: "5px",
  margin: "20px 0",
}

const subheading = {
  marginTop: "0",
  color: "#0C4A6E",
}

const table = {
  width: "100%",
  borderCollapse: "collapse" as const,
}

const tableLabel = {
  padding: "8px",
  textAlign: "left" as const,
  fontWeight: "bold",
  width: "40%",
}

const tableValue = {
  padding: "8px",
  textAlign: "left" as const,
}

const buttonContainer = {
  textAlign: "center" as const,
  margin: "30px 0",
}

const button = {
  backgroundColor: "#0C4A6E",
  color: "white",
  padding: "12px 24px",
  borderRadius: "5px",
  textDecoration: "none",
  fontWeight: "bold",
}

const footer = {
  borderTop: "1px solid #e0e0e0",
  padding: "20px 0",
  textAlign: "center" as const,
}

const footerText = {
  fontSize: "12px",
  color: "#666",
  margin: "5px 0",
}

