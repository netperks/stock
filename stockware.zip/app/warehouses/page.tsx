import { WarehouseCard } from "@/components/warehouse-card"
import { WarehouseFilters } from "@/components/warehouse-filters"

export default function WarehousesPage() {
  // Mock warehouse data
  const warehouses = [
    {
      id: "1",
      name: "Mega Storage Hub",
      location: "Mumbai, Maharashtra",
      type: "Dry Storage",
      price: 25000,
      imageUrl: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "2",
      name: "Cool Keep Warehouse",
      location: "Delhi, NCR",
      type: "Cold Storage",
      price: 30000,
      imageUrl: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "3",
      name: "Secure Vault Storage",
      location: "Bangalore, Karnataka",
      type: "Hazardous Materials",
      price: 35000,
      imageUrl: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "4",
      name: "Urban Mini Storage",
      location: "Pune, Maharashtra",
      type: "Dry Storage",
      price: 18000,
      imageUrl: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "5",
      name: "Pharma Cold Chain",
      location: "Hyderabad, Telangana",
      type: "Cold Storage",
      price: 40000,
      imageUrl: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "6",
      name: "Logistics Hub Warehouse",
      location: "Chennai, Tamil Nadu",
      type: "Dry Storage",
      price: 28000,
      imageUrl: "/placeholder.svg?height=200&width=300",
    },
  ]

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Available Warehouses</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <WarehouseFilters />
        </div>

        <div className="lg:col-span-3">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {warehouses.map((warehouse) => (
              <WarehouseCard key={warehouse.id} warehouse={warehouse} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

