import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { BookingForm } from "@/components/booking-form"
import { MapPin, Calendar, Package, Thermometer, AlertTriangle } from "lucide-react"

export default function WarehouseDetailPage({ params }: { params: { id: string } }) {
  // Mock warehouse data
  const warehouses = {
    "1": {
      id: "1",
      name: "Mega Storage Hub",
      location: "Mumbai, Maharashtra",
      type: "Dry Storage",
      price: 25000,
      description:
        "A spacious dry storage warehouse with 24/7 security and easy highway access. Perfect for storing retail goods, furniture, and non-perishable items.",
      features: ["24/7 Security", "Loading Docks", "Inventory Management", "Fire Protection"],
      imageUrl: "/placeholder.svg?height=400&width=800",
      ownerName: "Rajesh Enterprises",
    },
    "2": {
      id: "2",
      name: "Cool Keep Warehouse",
      location: "Delhi, NCR",
      type: "Cold Storage",
      price: 30000,
      description:
        "State-of-the-art cold storage facility with temperature control from -20°C to +10°C. Ideal for perishable goods, pharmaceuticals, and food products.",
      features: ["Temperature Control", "Backup Generators", "24/7 Monitoring", "Inventory Tracking"],
      imageUrl: "/placeholder.svg?height=400&width=800",
      ownerName: "Sharma Cold Chain",
    },
    "3": {
      id: "3",
      name: "Secure Vault Storage",
      location: "Bangalore, Karnataka",
      type: "Hazardous Materials",
      price: 35000,
      description:
        "Specialized warehouse for hazardous materials with proper ventilation, containment systems, and regulatory compliance. Certified for chemical storage.",
      features: ["Hazmat Certification", "Spill Containment", "Ventilation Systems", "Regulatory Compliance"],
      imageUrl: "/placeholder.svg?height=400&width=800",
      ownerName: "SafeStore Solutions",
    },
  }

  const warehouse = warehouses[params.id as keyof typeof warehouses]

  if (!warehouse) {
    return (
      <div className="container mx-auto p-4 text-center">
        <h1 className="text-3xl font-bold mb-4">Warehouse Not Found</h1>
        <p className="mb-6">The warehouse you're looking for doesn't exist.</p>
        <Button asChild>
          <Link href="/warehouses">Back to Warehouses</Link>
        </Button>
      </div>
    )
  }

  const warehouseTypeIcons = {
    "Dry Storage": <Package className="h-5 w-5" />,
    "Cold Storage": <Thermometer className="h-5 w-5" />,
    "Hazardous Materials": <AlertTriangle className="h-5 w-5" />,
  }

  const icon = warehouseTypeIcons[warehouse.type as keyof typeof warehouseTypeIcons] || <Package className="h-5 w-5" />

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-2">{warehouse.name}</h1>
      <div className="flex items-center text-muted-foreground mb-6">
        <MapPin className="h-4 w-4 mr-1" />
        <span>{warehouse.location}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <div className="relative h-80 w-full rounded-lg overflow-hidden">
            <Image src={warehouse.imageUrl || "/placeholder.svg"} alt={warehouse.name} fill className="object-cover" />
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge className="flex items-center gap-1">
              {icon}
              {warehouse.type}
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              <Package className="h-4 w-4" />
              Large Capacity
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              Available Now
            </Badge>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-2">Description</h2>
            <p className="text-muted-foreground">{warehouse.description}</p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-2">Features</h2>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {warehouse.features.map((feature, index) => (
                <li key={index} className="flex items-center">
                  <div className="h-2 w-2 rounded-full bg-primary mr-2"></div>
                  {feature}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div>
          <div className="sticky top-8 space-y-6">
            <BookingForm warehouseId={warehouse.id} price={warehouse.price} warehouseName={warehouse.name} />

            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Owner Information</h3>
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-primary font-bold">{warehouse.ownerName[0]}</span>
                  </div>
                  <div>
                    <p className="font-medium">{warehouse.ownerName}</p>
                    <p className="text-sm text-muted-foreground">Member since 2023</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  Contact the owner for special requirements or custom arrangements.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

