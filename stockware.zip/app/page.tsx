import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight, Warehouse, TruckIcon, BarChart3 } from "lucide-react"

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 bg-gradient-to-r from-primary/10 to-primary/5">
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
                Real-Time Warehouse Booking & Management
              </h1>
              <p className="text-xl text-muted-foreground">
                Find, book, and manage warehouse spaces effortlessly. Optimize your storage and logistics with
                Stockware.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" asChild>
                  <Link href="/warehouses">
                    Browse Warehouses <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/auth/signin">List Your Warehouse</Link>
                </Button>
              </div>
            </div>
            <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Warehouse Management"
                fill
                className="object-cover"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Stockware</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-card p-6 rounded-lg border shadow-sm">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Warehouse className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Warehouse Booking</h3>
              <p className="text-muted-foreground">
                Find and book the perfect warehouse space for your needs with real-time availability and instant
                confirmation.
              </p>
            </div>
            <div className="bg-card p-6 rounded-lg border shadow-sm">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <TruckIcon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Logistics & Transportation</h3>
              <p className="text-muted-foreground">
                Optimize your logistics with real-time tracking and route planning for efficient warehouse operations.
              </p>
            </div>
            <div className="bg-card p-6 rounded-lg border shadow-sm">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <BarChart3 className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">AI-Powered Forecasting</h3>
              <p className="text-muted-foreground">
                Predict demand and optimize space allocation with our advanced AI algorithms for better inventory
                management.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Optimize Your Warehouse Operations?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of businesses that trust Stockware for their warehouse booking and management needs.
          </p>
          <Button size="lg" variant="secondary" asChild>
            <Link href="/auth/signin">Get Started Today</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}

