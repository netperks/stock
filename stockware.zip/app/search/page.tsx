import { PrismaClient } from "@prisma/client"
import { WarehouseCard } from "@/components/warehouse-card"

const prisma = new PrismaClient()

export default async function SearchResults({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const location = searchParams.location as string
  const type = searchParams.type as string

  const whereClause: any = {}

  if (location) {
    whereClause.location = {
      contains: location,
      mode: "insensitive",
    }
  }

  if (type) {
    whereClause.type = type
  }

  const warehouses = await prisma.warehouse.findMany({
    where: whereClause,
  })

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Search Results</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {warehouses.map((warehouse) => (
          <WarehouseCard key={warehouse.id} warehouse={warehouse} />
        ))}
      </div>
    </div>
  )
}

