"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, Loader2 } from "lucide-react"

export default function BookingsPage() {
  const { data: session, status } = useSession()
  const [bookings, setBookings] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === "authenticated") {
      fetchBookings()
    }
  }, [status])

  const fetchBookings = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/bookings")
      if (response.ok) {
        const data = await response.json()
        setBookings(data)
      }
    } catch (error) {
      console.error("Error fetching bookings:", error)
    } finally {
      setLoading(false)
    }
  }

  if (status === "loading" || loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!session) {
    return (
      <div className="text-center py-12">
        <h1 className="text-3xl font-bold mb-4">Access Denied</h1>
        <p className="mb-6">Please sign in to view your bookings.</p>
        <Button asChild>
          <Link href="/auth/signin?callbackUrl=/dashboard/bookings">Sign In</Link>
        </Button>
      </div>
    )
  }

  // For demo purposes, let's create some mock bookings
  const mockBookings = [
    {
      id: "1",
      warehouse: {
        name: "Mega Storage Hub",
        location: "Mumbai, Maharashtra",
      },
      startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
      endDate: new Date(Date.now() + 23 * 24 * 60 * 60 * 1000), // 23 days from now
      totalPrice: 25000,
      days: 30,
      status: "ACTIVE",
    },
    {
      id: "2",
      warehouse: {
        name: "Cool Keep Warehouse",
        location: "Delhi, NCR",
      },
      startDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
      endDate: new Date(Date.now() + 40 * 24 * 60 * 60 * 1000), // 40 days from now
      totalPrice: 30000,
      days: 30,
      status: "UPCOMING",
    },
    {
      id: "3",
      warehouse: {
        name: "Secure Vault Storage",
        location: "Bangalore, Karnataka",
      },
      startDate: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), // 60 days ago
      endDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
      totalPrice: 35000,
      days: 30,
      status: "COMPLETED",
    },
  ]

  // Group bookings by status
  const now = new Date()

  const activeBookings = mockBookings.filter((booking) => booking.status === "ACTIVE")

  const upcomingBookings = mockBookings.filter((booking) => booking.status === "UPCOMING")

  const pastBookings = mockBookings.filter((booking) => booking.status === "COMPLETED")

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">My Bookings</h1>

      {mockBookings.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground mb-4">You don't have any bookings yet</p>
            <Button asChild>
              <Link href="/warehouses">Browse Warehouses</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-8">
          {activeBookings.length > 0 && (
            <div>
              <h2 className="text-xl font-bold mb-4">Active Bookings</h2>
              <div className="space-y-4">
                {activeBookings.map((booking) => (
                  <BookingCard key={booking.id} booking={booking} />
                ))}
              </div>
            </div>
          )}

          {upcomingBookings.length > 0 && (
            <div>
              <h2 className="text-xl font-bold mb-4">Upcoming Bookings</h2>
              <div className="space-y-4">
                {upcomingBookings.map((booking) => (
                  <BookingCard key={booking.id} booking={booking} />
                ))}
              </div>
            </div>
          )}

          {pastBookings.length > 0 && (
            <div>
              <h2 className="text-xl font-bold mb-4">Past Bookings</h2>
              <div className="space-y-4">
                {pastBookings.map((booking) => (
                  <BookingCard key={booking.id} booking={booking} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function BookingCard({ booking }: { booking: any }) {
  const startDate = new Date(booking.startDate)
  const endDate = new Date(booking.endDate)
  const now = new Date()

  let statusBadge

  if (booking.status === "ACTIVE") {
    statusBadge = <Badge className="bg-green-100 text-green-800">Active</Badge>
  } else if (booking.status === "UPCOMING") {
    statusBadge = <Badge className="bg-blue-100 text-blue-800">Upcoming</Badge>
  } else if (booking.status === "COMPLETED") {
    statusBadge = <Badge className="bg-gray-100 text-gray-800">Completed</Badge>
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-lg">{booking.warehouse.name}</h3>
              {statusBadge}
            </div>
            <div className="flex items-center text-muted-foreground mb-2">
              <MapPin className="h-4 w-4 mr-1" />
              <span className="text-sm">{booking.warehouse.location}</span>
            </div>
            <div className="flex items-center text-muted-foreground">
              <Calendar className="h-4 w-4 mr-1" />
              <span className="text-sm">
                {startDate.toLocaleDateString()} - {endDate.toLocaleDateString()}
              </span>
            </div>
          </div>
          <div className="mt-4 md:mt-0 md:text-right">
            <p className="font-bold text-lg">₹{booking.totalPrice.toLocaleString()}</p>
            <p className="text-sm text-muted-foreground">
              {booking.days} {booking.days === 1 ? "day" : "days"}
            </p>
            <div className="mt-2">
              <Button asChild size="sm" variant="outline">
                <Link href={`/dashboard/bookings/${booking.id}`}>View Details</Link>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

