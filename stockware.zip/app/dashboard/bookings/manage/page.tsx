"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { toast } from "@/components/ui/use-toast"
import { Loader2, Search, Filter, Calendar, MapPin, Package, Clock, CheckCircle, XCircle } from "lucide-react"

export default function BookingManagementPage() {
  const { data: session, status } = useSession()
  const [bookings, setBookings] = useState<any[]>([])
  const [filteredBookings, setFilteredBookings] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateFilter, setDateFilter] = useState("all")

  useEffect(() => {
    if (status === "authenticated") {
      fetchBookings()
    }
  }, [status])

  useEffect(() => {
    filterBookings()
  }, [bookings, searchTerm, statusFilter, dateFilter])

  const fetchBookings = async () => {
    try {
      setLoading(true)
      // In a real app, we would fetch from the API
      // const response = await fetch("/api/bookings/manage")
      // if (response.ok) {
      //   const data = await response.json()
      //   setBookings(data)
      // }

      // For demo purposes, let's create mock bookings
      setTimeout(() => {
        const mockBookings = generateMockBookings(20)
        setBookings(mockBookings)
        setLoading(false)
      }, 1000)
    } catch (error) {
      console.error("Error fetching bookings:", error)
      setLoading(false)
    }
  }

  const filterBookings = () => {
    let filtered = [...bookings]

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (booking) =>
          booking.customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          booking.warehouse.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          booking.id.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((booking) => booking.status === statusFilter)
    }

    // Apply date filter
    const now = new Date()
    if (dateFilter === "today") {
      filtered = filtered.filter((booking) => new Date(booking.startDate) <= now && new Date(booking.endDate) >= now)
    } else if (dateFilter === "upcoming") {
      filtered = filtered.filter((booking) => new Date(booking.startDate) > now)
    } else if (dateFilter === "past") {
      filtered = filtered.filter((booking) => new Date(booking.endDate) < now)
    }

    setFilteredBookings(filtered)
  }

  const handleStatusChange = async (bookingId: string, newStatus: string) => {
    try {
      // In a real app, we would call an API to update the booking status
      // const response = await fetch(`/api/bookings/${bookingId}/status`, {
      //   method: "PATCH",
      //   headers: { "Content-Type": "application/json" },
      //   body: JSON.stringify({ status: newStatus }),
      // })

      // For demo purposes, just update the local state
      const updatedBookings = bookings.map((booking) => {
        if (booking.id === bookingId) {
          return { ...booking, status: newStatus }
        }
        return booking
      })

      setBookings(updatedBookings)

      toast({
        title: "Booking status updated",
        description: `Booking #${bookingId.substring(0, 8)} has been marked as ${newStatus.toLowerCase()}.`,
      })
    } catch (error) {
      console.error("Error updating booking status:", error)
      toast({
        title: "Error updating booking status",
        description: "Please try again later.",
        variant: "destructive",
      })
    }
  }

  if (status === "loading" || loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!session) {
    return (
      <div className="text-center py-12">
        <h1 className="text-3xl font-bold mb-4">Access Denied</h1>
        <p className="mb-6">Please sign in to manage bookings.</p>
        <Button asChild>
          <Link href="/auth/signin?callbackUrl=/dashboard/bookings/manage">Sign In</Link>
        </Button>
      </div>
    )
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Booking Management</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search by customer, warehouse, or booking ID"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="CONFIRMED">Confirmed</SelectItem>
              <SelectItem value="PENDING">Pending</SelectItem>
              <SelectItem value="CANCELLED">Cancelled</SelectItem>
              <SelectItem value="COMPLETED">Completed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={dateFilter} onValueChange={setDateFilter}>
            <SelectTrigger className="w-[180px]">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter by date" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Dates</SelectItem>
              <SelectItem value="today">Active Today</SelectItem>
              <SelectItem value="upcoming">Upcoming</SelectItem>
              <SelectItem value="past">Past</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="list" className="space-y-4">
        <TabsList>
          <TabsTrigger value="list">List View</TabsTrigger>
          <TabsTrigger value="calendar">Calendar View</TabsTrigger>
        </TabsList>
        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>All Bookings</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredBookings.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No bookings found matching your filters.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredBookings.map((booking) => (
                    <BookingItem key={booking.id} booking={booking} onStatusChange={handleStatusChange} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="calendar">
          <Card>
            <CardHeader>
              <CardTitle>Calendar View</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[600px] flex items-center justify-center">
                <p className="text-muted-foreground">Calendar view coming soon...</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function BookingItem({
  booking,
  onStatusChange,
}: { booking: any; onStatusChange: (id: string, status: string) => void }) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "CONFIRMED":
        return <Badge className="bg-green-100 text-green-800">Confirmed</Badge>
      case "PENDING":
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
      case "CANCELLED":
        return <Badge className="bg-red-100 text-red-800">Cancelled</Badge>
      case "COMPLETED":
        return <Badge className="bg-blue-100 text-blue-800">Completed</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="border rounded-lg p-4">
      <div className="flex flex-col md:flex-row justify-between">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold">Booking #{booking.id.substring(0, 8)}</h3>
            {getStatusBadge(booking.status)}
          </div>
          <div className="flex items-center text-muted-foreground">
            <Package className="h-4 w-4 mr-1" />
            <span className="text-sm">{booking.warehouse.name}</span>
          </div>
          <div className="flex items-center text-muted-foreground">
            <MapPin className="h-4 w-4 mr-1" />
            <span className="text-sm">{booking.warehouse.location}</span>
          </div>
          <div className="flex items-center text-muted-foreground">
            <Calendar className="h-4 w-4 mr-1" />
            <span className="text-sm">
              {new Date(booking.startDate).toLocaleDateString()} - {new Date(booking.endDate).toLocaleDateString()}
            </span>
          </div>
        </div>
        <div className="mt-4 md:mt-0 md:text-right">
          <p className="font-bold text-lg">₹{booking.totalPrice.toLocaleString()}</p>
          <p className="text-sm text-muted-foreground">
            {booking.customer.name} • {booking.customer.email}
          </p>
          <p className="text-sm text-muted-foreground">
            <Clock className="h-4 w-4 inline mr-1" />
            Booked on {new Date(booking.createdAt).toLocaleDateString()}
          </p>
          <div className="flex gap-2 mt-2 md:justify-end">
            <Button asChild size="sm" variant="outline">
              <Link href={`/dashboard/bookings/${booking.id}`}>View Details</Link>
            </Button>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm">Manage</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Manage Booking #{booking.id.substring(0, 8)}</DialogTitle>
                  <DialogDescription>Update the status of this booking or perform other actions.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <h4 className="font-medium">Booking Details</h4>
                    <p className="text-sm">
                      <strong>Warehouse:</strong> {booking.warehouse.name}
                    </p>
                    <p className="text-sm">
                      <strong>Customer:</strong> {booking.customer.name}
                    </p>
                    <p className="text-sm">
                      <strong>Period:</strong> {new Date(booking.startDate).toLocaleDateString()} -{" "}
                      {new Date(booking.endDate).toLocaleDateString()}
                    </p>
                    <p className="text-sm">
                      <strong>Amount:</strong> ₹{booking.totalPrice.toLocaleString()}
                    </p>
                    <p className="text-sm">
                      <strong>Current Status:</strong> {booking.status}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium">Update Status</h4>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex items-center"
                        onClick={() => {
                          onStatusChange(booking.id, "CONFIRMED")
                          setIsDialogOpen(false)
                        }}
                        disabled={booking.status === "CONFIRMED"}
                      >
                        <CheckCircle className="h-4 w-4 mr-1 text-green-500" />
                        Confirm
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex items-center"
                        onClick={() => {
                          onStatusChange(booking.id, "COMPLETED")
                          setIsDialogOpen(false)
                        }}
                        disabled={booking.status === "COMPLETED"}
                      >
                        <CheckCircle className="h-4 w-4 mr-1 text-blue-500" />
                        Complete
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex items-center"
                        onClick={() => {
                          onStatusChange(booking.id, "CANCELLED")
                          setIsDialogOpen(false)
                        }}
                        disabled={booking.status === "CANCELLED"}
                      >
                        <XCircle className="h-4 w-4 mr-1 text-red-500" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Close
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </div>
  )
}

// Helper function to generate mock bookings
function generateMockBookings(count: number) {
  const warehouses = [
    { id: "1", name: "Mega Storage Hub", location: "Mumbai, Maharashtra", type: "Dry Storage" },
    { id: "2", name: "Cool Keep Warehouse", location: "Delhi, NCR", type: "Cold Storage" },
    { id: "3", name: "Secure Vault Storage", location: "Bangalore, Karnataka", type: "Hazardous Materials" },
    { id: "4", name: "Urban Mini Storage", location: "Pune, Maharashtra", type: "Dry Storage" },
    { id: "5", name: "Pharma Cold Chain", location: "Hyderabad, Telangana", type: "Cold Storage" },
  ]

  const customers = [
    { id: "1", name: "Rajesh Kumar", email: "rajesh@example.com" },
    { id: "2", name: "Priya Sharma", email: "priya@example.com" },
    { id: "3", name: "Amit Patel", email: "amit@example.com" },
    { id: "4", name: "Sneha Gupta", email: "sneha@example.com" },
    { id: "5", name: "Vikram Singh", email: "vikram@example.com" },
  ]

  const statuses = ["CONFIRMED", "PENDING", "CANCELLED", "COMPLETED"]

  const bookings = []
  const now = new Date()

  for (let i = 0; i < count; i++) {
    const warehouse = warehouses[Math.floor(Math.random() * warehouses.length)]
    const customer = customers[Math.floor(Math.random() * customers.length)]
    const status = statuses[Math.floor(Math.random() * statuses.length)]

    // Generate random dates
    const createdAt = new Date(now)
    createdAt.setDate(createdAt.getDate() - Math.floor(Math.random() * 30))

    const startDate = new Date(createdAt)
    startDate.setDate(startDate.getDate() + Math.floor(Math.random() * 15))

    const endDate = new Date(startDate)
    endDate.setDate(endDate.getDate() + Math.floor(Math.random() * 30) + 5)

    const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
    const pricePerDay = Math.floor(Math.random() * 1000) + 500
    const totalPrice = days * pricePerDay

    bookings.push({
      id: `booking-${i}-${Math.random().toString(36).substring(2, 10)}`,
      warehouse,
      customer,
      status,
      startDate,
      endDate,
      createdAt,
      days,
      totalPrice,
      orderId: `order-${Math.random().toString(36).substring(2, 10)}`,
      paymentId: `pay-${Math.random().toString(36).substring(2, 10)}`,
    })
  }

  return bookings
}

