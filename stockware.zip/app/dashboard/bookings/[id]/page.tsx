"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Calendar, MapPin, Clock, FileText, Loader2, ArrowLeft, Download } from "lucide-react"

export default function BookingDetailPage({ params }: { params: { id: string } }) {
  const { data: session, status } = useSession()
  const [booking, setBooking] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === "authenticated") {
      fetchBooking()
    }
  }, [status, params.id])

  const fetchBooking = async () => {
    try {
      setLoading(true)
      // In a real app, we would fetch from the API
      // const response = await fetch(`/api/bookings/${params.id}`)
      // if (response.ok) {
      //   const data = await response.json()
      //   setBooking(data)
      // }

      // For demo purposes, let's create a mock booking
      const mockBooking = {
        id: params.id,
        warehouse: {
          id: "1",
          name: "Mega Storage Hub",
          location: "Mumbai, Maharashtra",
          type: "Dry Storage",
          imageUrl: "/placeholder.svg?height=200&width=300",
        },
        startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
        endDate: new Date(Date.now() + 23 * 24 * 60 * 60 * 1000), // 23 days from now
        totalPrice: 25000,
        days: 30,
        status: "ACTIVE",
        paymentId: "pay_" + Math.random().toString(36).substring(2, 15),
        orderId: "order_" + Math.random().toString(36).substring(2, 15),
        createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
      }

      setBooking(mockBooking)
    } catch (error) {
      console.error("Error fetching booking:", error)
    } finally {
      setLoading(false)
    }
  }

  if (status === "loading" || loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!session) {
    return (
      <div className="text-center py-12">
        <h1 className="text-3xl font-bold mb-4">Access Denied</h1>
        <p className="mb-6">Please sign in to view booking details.</p>
        <Button asChild>
          <Link href={`/auth/signin?callbackUrl=/dashboard/bookings/${params.id}`}>Sign In</Link>
        </Button>
      </div>
    )
  }

  if (!booking) {
    return (
      <div className="text-center py-12">
        <h1 className="text-3xl font-bold mb-4">Booking Not Found</h1>
        <p className="mb-6">The booking you're looking for doesn't exist or you don't have permission to view it.</p>
        <Button asChild>
          <Link href="/dashboard/bookings">Back to Bookings</Link>
        </Button>
      </div>
    )
  }

  const startDate = new Date(booking.startDate)
  const endDate = new Date(booking.endDate)
  const createdAt = new Date(booking.createdAt)
  const now = new Date()

  let statusBadge
  let statusColor

  if (booking.status === "ACTIVE") {
    statusBadge = <Badge className="bg-green-100 text-green-800">Active</Badge>
    statusColor = "text-green-600"
  } else if (booking.status === "UPCOMING") {
    statusBadge = <Badge className="bg-blue-100 text-blue-800">Upcoming</Badge>
    statusColor = "text-blue-600"
  } else if (booking.status === "COMPLETED") {
    statusBadge = <Badge className="bg-gray-100 text-gray-800">Completed</Badge>
    statusColor = "text-gray-600"
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
        <div>
          <Button variant="ghost" size="sm" asChild className="mb-2">
            <Link href="/dashboard/bookings">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Bookings
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">Booking Details</h1>
        </div>
        <div className="mt-4 sm:mt-0">
          <Button variant="outline" size="sm" className="mr-2">
            <Download className="h-4 w-4 mr-2" />
            Download Invoice
          </Button>
          <Button size="sm">
            <FileText className="h-4 w-4 mr-2" />
            View Receipt
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Warehouse Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-6">
                <div className="relative h-48 w-full md:w-48 rounded-lg overflow-hidden">
                  <Image
                    src={booking.warehouse.imageUrl || "/placeholder.svg"}
                    alt={booking.warehouse.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2">{booking.warehouse.name}</h3>
                  <div className="flex items-center text-muted-foreground mb-2">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{booking.warehouse.location}</span>
                  </div>
                  <Badge variant="outline" className="mb-4">
                    {booking.warehouse.type}
                  </Badge>
                  <div className="mt-4">
                    <Button asChild variant="outline" size="sm">
                      <Link href={`/warehouses/${booking.warehouse.id}`}>View Warehouse</Link>
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Booking Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Booking Period</h4>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>
                      {startDate.toLocaleDateString()} - {endDate.toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {booking.days} {booking.days === 1 ? "day" : "days"}
                  </p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Booking Status</h4>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2" />
                    <span className={statusColor}>{booking.status}</span>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Booking Date</h4>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{createdAt.toLocaleDateString()}</span>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Booking ID</h4>
                  <div className="flex items-center">
                    <FileText className="h-4 w-4 mr-2" />
                    <span className="font-mono text-sm">{booking.id}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Payment Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Price per day</span>
                  <span>₹{(booking.totalPrice / booking.days).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Number of days</span>
                  <span>{booking.days}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold">
                  <span>Total Amount</span>
                  <span>₹{booking.totalPrice.toLocaleString()}</span>
                </div>
                <div className="bg-muted p-3 rounded-md mt-4">
                  <h4 className="text-sm font-medium mb-2">Payment Information</h4>
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Payment ID</span>
                      <span className="font-mono">{booking.paymentId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Order ID</span>
                      <span className="font-mono">{booking.orderId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Payment Status</span>
                      <span className="text-green-600">Paid</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

