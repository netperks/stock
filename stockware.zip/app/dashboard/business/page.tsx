import { PaymentHistory } from "@/components/payment-history"
import { PaymentSummary } from "@/components/payment-summary"

export default function BusinessDashboard() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Business Dashboard</h1>
      <div className="space-y-8">
        <PaymentSummary />
        <PaymentHistory />
      </div>
    </div>
  )
}

