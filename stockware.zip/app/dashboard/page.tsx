import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, CreditCard, DollarSign, Users } from "lucide-react"

export default function Dashboard() {
  // Mock data
  const stats = [
    {
      title: "Total Bookings",
      value: "12",
      icon: Calendar,
      description: "All-time bookings",
    },
    {
      title: "Active Bookings",
      value: "3",
      icon: Users,
      description: "Currently active",
    },
    {
      title: "Total Spent",
      value: "₹2,45,000",
      icon: DollarSign,
      description: "Lifetime spending",
    },
    {
      title: "Upcoming Bookings",
      value: "2",
      icon: CreditCard,
      description: "Next 30 days",
    },
  ]

  const recentBookings = [
    {
      id: "1",
      warehouse: "Mega Storage Hub",
      location: "Mumbai, Maharashtra",
      price: 25000,
      startDate: "2023-10-01",
      endDate: "2023-11-01",
    },
    {
      id: "2",
      warehouse: "Cool Keep Warehouse",
      location: "Delhi, NCR",
      price: 30000,
      startDate: "2023-11-05",
      endDate: "2023-12-05",
    },
    {
      id: "3",
      warehouse: "Secure Vault Storage",
      location: "Bangalore, Karnataka",
      price: 35000,
      startDate: "2023-12-10",
      endDate: "2024-01-10",
    },
  ]

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">{stat.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <h2 className="text-xl font-bold mb-4">Recent Bookings</h2>

      <div className="space-y-4 mb-6">
        {recentBookings.map((booking) => (
          <Card key={booking.id}>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row justify-between">
                <div>
                  <h3 className="font-semibold">{booking.warehouse}</h3>
                  <p className="text-sm text-muted-foreground">{booking.location}</p>
                </div>
                <div className="mt-2 md:mt-0 md:text-right">
                  <p className="font-bold">₹{booking.price.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(booking.startDate).toLocaleDateString()} -{" "}
                    {new Date(booking.endDate).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-center">
        <Button asChild variant="outline">
          <Link href="/warehouses">Browse More Warehouses</Link>
        </Button>
      </div>
    </div>
  )
}

