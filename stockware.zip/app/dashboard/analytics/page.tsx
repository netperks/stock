"use client"

import Link from "next/link"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, TrendingUp, TrendingDown, DollarSign, Users, Calendar, Package } from "lucide-react"
import { OccupancyChart } from "@/components/analytics/occupancy-chart"
import { RevenueChart } from "@/components/analytics/revenue-chart"
import { BookingTrendsChart } from "@/components/analytics/booking-trends-chart"
import { PopularWarehousesChart } from "@/components/analytics/popular-warehouses-chart"

export default function AnalyticsPage() {
  const { data: session, status } = useSession()
  const [timeframe, setTimeframe] = useState("30days")
  const [loading, setLoading] = useState(true)
  const [analyticsData, setAnalyticsData] = useState<any>(null)

  useEffect(() => {
    if (status === "authenticated") {
      fetchAnalyticsData()
    }
  }, [status, timeframe])

  const fetchAnalyticsData = async () => {
    try {
      setLoading(true)
      // In a real app, we would fetch from the API with the timeframe parameter
      // const response = await fetch(`/api/analytics?timeframe=${timeframe}`)
      // if (response.ok) {
      //   const data = await response.json()
      //   setAnalyticsData(data)
      // }

      // For demo purposes, let's create mock analytics data
      setTimeout(() => {
        setAnalyticsData({
          summary: {
            totalRevenue: 250000,
            revenueChange: 12.5,
            totalBookings: 45,
            bookingsChange: 8.2,
            occupancyRate: 78,
            occupancyChange: 5.3,
            activeWarehouses: 8,
          },
          occupancyData: generateOccupancyData(),
          revenueData: generateRevenueData(),
          bookingTrendsData: generateBookingTrendsData(),
          popularWarehousesData: generatePopularWarehousesData(),
        })
        setLoading(false)
      }, 1000)
    } catch (error) {
      console.error("Error fetching analytics data:", error)
      setLoading(false)
    }
  }

  if (status === "loading" || loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!session) {
    return (
      <div className="text-center py-12">
        <h1 className="text-3xl font-bold mb-4">Access Denied</h1>
        <p className="mb-6">Please sign in to view analytics.</p>
        <Button asChild>
          <Link href="/auth/signin?callbackUrl=/dashboard/analytics">Sign In</Link>
        </Button>
      </div>
    )
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
        <h1 className="text-3xl font-bold">Analytics Dashboard</h1>
        <div className="mt-4 sm:mt-0">
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
              <SelectItem value="year">Last year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {analyticsData && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹{analyticsData.summary.totalRevenue.toLocaleString()}</div>
                <div className="flex items-center mt-1">
                  {analyticsData.summary.revenueChange > 0 ? (
                    <>
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500 text-xs">
                        {analyticsData.summary.revenueChange}% from last period
                      </span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      <span className="text-red-500 text-xs">
                        {Math.abs(analyticsData.summary.revenueChange)}% from last period
                      </span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.summary.totalBookings}</div>
                <div className="flex items-center mt-1">
                  {analyticsData.summary.bookingsChange > 0 ? (
                    <>
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500 text-xs">
                        {analyticsData.summary.bookingsChange}% from last period
                      </span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      <span className="text-red-500 text-xs">
                        {Math.abs(analyticsData.summary.bookingsChange)}% from last period
                      </span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Occupancy Rate</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.summary.occupancyRate}%</div>
                <div className="flex items-center mt-1">
                  {analyticsData.summary.occupancyChange > 0 ? (
                    <>
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500 text-xs">
                        {analyticsData.summary.occupancyChange}% from last period
                      </span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      <span className="text-red-500 text-xs">
                        {Math.abs(analyticsData.summary.occupancyChange)}% from last period
                      </span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Warehouses</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.summary.activeWarehouses}</div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="occupancy" className="space-y-4">
            <TabsList>
              <TabsTrigger value="occupancy">Occupancy</TabsTrigger>
              <TabsTrigger value="revenue">Revenue</TabsTrigger>
              <TabsTrigger value="bookings">Booking Trends</TabsTrigger>
              <TabsTrigger value="popular">Popular Warehouses</TabsTrigger>
            </TabsList>
            <TabsContent value="occupancy" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Warehouse Occupancy Rate</CardTitle>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <OccupancyChart data={analyticsData.occupancyData} />
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="revenue" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Analysis</CardTitle>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <RevenueChart data={analyticsData.revenueData} />
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="bookings" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Booking Trends</CardTitle>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <BookingTrendsChart data={analyticsData.bookingTrendsData} />
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="popular" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Popular Warehouses</CardTitle>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <PopularWarehousesChart data={analyticsData.popularWarehousesData} />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  )
}

// Helper functions to generate mock data
function generateOccupancyData() {
  const data = []
  const now = new Date()
  for (let i = 30; i >= 0; i--) {
    const date = new Date(now)
    date.setDate(date.getDate() - i)
    data.push({
      date: date.toISOString().split("T")[0],
      occupancyRate: Math.floor(Math.random() * 30) + 60, // Random between 60-90%
    })
  }
  return data
}

function generateRevenueData() {
  const data = []
  const now = new Date()
  for (let i = 30; i >= 0; i--) {
    const date = new Date(now)
    date.setDate(date.getDate() - i)
    data.push({
      date: date.toISOString().split("T")[0],
      revenue: Math.floor(Math.random() * 10000) + 5000, // Random between 5000-15000
    })
  }
  return data
}

function generateBookingTrendsData() {
  return [
    { month: "Jan", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Feb", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Mar", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Apr", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "May", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Jun", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Jul", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Aug", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Sep", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Oct", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Nov", bookings: Math.floor(Math.random() * 20) + 10 },
    { month: "Dec", bookings: Math.floor(Math.random() * 20) + 10 },
  ]
}

function generatePopularWarehousesData() {
  return [
    { name: "Mega Storage Hub", bookings: Math.floor(Math.random() * 30) + 20 },
    { name: "Cool Keep Warehouse", bookings: Math.floor(Math.random() * 30) + 20 },
    { name: "Secure Vault Storage", bookings: Math.floor(Math.random() * 30) + 20 },
    { name: "Urban Mini Storage", bookings: Math.floor(Math.random() * 30) + 20 },
    { name: "Pharma Cold Chain", bookings: Math.floor(Math.random() * 30) + 20 },
  ]
}

