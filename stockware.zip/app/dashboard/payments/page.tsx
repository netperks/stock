"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, Calendar, CreditCard } from "lucide-react"
import { getBookingsByUserId } from "@/lib/mock-data"

export default function PaymentsPage() {
  const { user } = useAuth()
  const [payments, setPayments] = useState<any[]>([])
  const [stats, setStats] = useState({
    totalSpent: 0,
    activeBookings: 0,
    upcomingBookings: 0,
  })

  useEffect(() => {
    if (user) {
      const userBookings = getBookingsByUserId(user.id)
      setPayments(userBookings)

      // Calculate stats
      const now = new Date()
      const active = userBookings.filter(
        (booking) =>
          booking.status === "CONFIRMED" && new Date(booking.startDate) <= now && new Date(booking.endDate) >= now,
      ).length

      const upcoming = userBookings.filter(
        (booking) => booking.status === "CONFIRMED" && new Date(booking.startDate) > now,
      ).length

      const total = userBookings.reduce((sum, booking) => sum + booking.totalPrice, 0)

      setStats({
        totalSpent: total,
        activeBookings: active,
        upcomingBookings: upcoming,
      })
    }
  }, [user])

  if (!user) return null

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Payments</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{stats.totalSpent.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Bookings</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeBookings}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Bookings</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.upcomingBookings}</div>
          </CardContent>
        </Card>
      </div>

      <h2 className="text-xl font-bold mb-4">Payment History</h2>

      {payments.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground mb-4">No payment history available</p>
            <Button asChild>
              <Link href="/warehouses">Browse Warehouses</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {payments.map((payment) => (
            <Card key={payment.id}>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">{payment.warehouse.name}</h3>
                    <p className="text-sm text-muted-foreground">{new Date(payment.createdAt).toLocaleDateString()}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className="bg-green-100 text-green-800">Paid</Badge>
                      <span className="text-sm text-muted-foreground">Order #{payment.orderId.substring(0, 8)}</span>
                    </div>
                  </div>
                  <div className="mt-4 md:mt-0 md:text-right">
                    <p className="font-bold text-lg">₹{payment.totalPrice.toLocaleString()}</p>
                    <div className="mt-2">
                      <Button asChild size="sm" variant="outline">
                        <Link href="#">
                          <Download className="h-4 w-4 mr-2" />
                          Download Invoice
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

