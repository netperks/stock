import { getServerSession } from "next-auth/next"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { WarehouseOwnerStats } from "@/components/warehouse-owner-stats"
import { WarehouseManagementList } from "@/components/warehouse-management-list"
import clientPromise from "@/lib/mongodb"

export default async function WarehouseOwnerDashboard() {
  const session = await getServerSession()

  if (!session?.user?.email) {
    redirect("/api/auth/signin")
  }

  const client = await clientPromise
  const db = client.db("stockware")

  const user = await db.collection("users").findOne({ email: session.user.email })

  if (!user || user.role !== "WAREHOUSE_OWNER") {
    redirect("/")
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Warehouse Owner Dashboard</h1>
        <Link href="/dashboard/warehouse-owner/add">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Warehouse
          </Button>
        </Link>
      </div>

      <WarehouseOwnerStats userId={user._id.toString()} />

      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-4">Your Warehouses</h2>
        <WarehouseManagementList userId={user._id.toString()} />
      </div>
    </div>
  )
}

