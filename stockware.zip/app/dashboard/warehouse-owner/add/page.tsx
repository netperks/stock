import { getServerSession } from "next-auth/next"
import { redirect } from "next/navigation"
import { AddWarehouseForm } from "@/components/add-warehouse-form"
import clientPromise from "@/lib/mongodb"

export default async function AddWarehousePage() {
  const session = await getServerSession()

  if (!session?.user?.email) {
    redirect("/api/auth/signin")
  }

  const client = await clientPromise
  const db = client.db("stockware")

  const user = await db.collection("users").findOne({ email: session.user.email })

  if (!user || user.role !== "WAREHOUSE_OWNER") {
    redirect("/")
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Add New Warehouse</h1>
      <AddWarehouseForm userId={user._id.toString()} />
    </div>
  )
}

