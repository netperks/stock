import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

function simpleForecasting(historicalData: number[]): number {
  // This is a very simple moving average forecast
  // In a real-world scenario, you'd use more sophisticated methods
  const sum = historicalData.reduce((a, b) => a + b, 0)
  return Math.round(sum / historicalData.length)
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const warehouseId = searchParams.get("warehouseId")

  if (!warehouseId) {
    return NextResponse.json({ error: "Warehouse ID is required" }, { status: 400 })
  }

  const inventoryItems = await prisma.inventory.findMany({
    where: { warehouseId },
    orderBy: { updatedAt: "desc" },
    take: 30, // Last 30 inventory updates
  })

  const itemsMap = inventoryItems.reduce((acc, item) => {
    if (!acc[item.itemName]) {
      acc[item.itemName] = []
    }
    acc[item.itemName].push(item.quantity)
    return acc
  }, {})

  const forecast = Object.entries(itemsMap).map(([itemName, quantities]) => ({
    itemName,
    forecastedQuantity: simpleForecasting(quantities),
  }))

  return NextResponse.json(forecast)
}

