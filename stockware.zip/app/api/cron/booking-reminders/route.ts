import { NextResponse } from "next/server"
import clientPromise from "@/lib/mongodb"
import { sendBookingReminder } from "@/lib/email"

// This endpoint should be called by a cron job (e.g., Vercel Cron)
export async function GET(request: Request) {
  try {
    // Verify the request is from an authorized source
    const authHeader = request.headers.get("authorization")
    if (authHeader !== `Bearer ${process.env.CRON_SECRET_KEY}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const client = await clientPromise
    const db = client.db("stockware")

    // Get tomorrow's date
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    tomorrow.setHours(0, 0, 0, 0)

    const nextDay = new Date(tomorrow)
    nextDay.setDate(nextDay.getDate() + 1)

    // Find bookings that start tomorrow
    const bookings = await db
      .collection("bookings")
      .aggregate([
        {
          $match: {
            startDate: {
              $gte: tomorrow,
              $lt: nextDay,
            },
            status: "CONFIRMED",
          },
        },
        {
          $lookup: {
            from: "warehouses",
            localField: "warehouseId",
            foreignField: "_id",
            as: "warehouse",
          },
        },
        {
          $unwind: "$warehouse",
        },
        {
          $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "user",
          },
        },
        {
          $unwind: "$user",
        },
      ])
      .toArray()

    // Send reminder emails
    const emailPromises = bookings.map((booking) => {
      return sendBookingReminder(booking.user.email, booking.user.name || "Customer", {
        bookingId: booking._id.toString(),
        warehouseName: booking.warehouse.name,
        startDate: booking.startDate,
        endDate: booking.endDate,
        amount: booking.totalPrice,
        orderId: booking.orderId,
      })
    })

    await Promise.all(emailPromises)

    return NextResponse.json({
      success: true,
      emailsSent: bookings.length,
    })
  } catch (error) {
    console.error("Error sending booking reminders:", error)
    return NextResponse.json({ error: "Failed to send booking reminders" }, { status: 500 })
  }
}

