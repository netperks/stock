import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function POST(request: Request) {
  const body = await request.json()
  const booking = await prisma.booking.create({
    data: {
      ...body,
      status: "PENDING",
      totalPrice: 0, // Calculate this based on the duration and warehouse price
    },
  })
  return NextResponse.json(booking)
}

