import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"
import crypto from "crypto"

export async function POST(request: Request) {
  try {
    const session = await getServerSession()

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { razorpay_payment_id, razorpay_order_id, razorpay_signature, warehouseId, startDate, endDate, days } = body

    // Verify payment signature
    const text = `${razorpay_order_id}|${razorpay_payment_id}`
    const signature = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET!).update(text).digest("hex")

    if (signature !== razorpay_signature) {
      return NextResponse.json({ error: "Invalid payment signature" }, { status: 400 })
    }

    const client = await clientPromise
    const db = client.db("stockware")

    // Get user from session
    const user = await db.collection("users").findOne({ email: session.user.email })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Get warehouse details
    const warehouse = await db.collection("warehouses").findOne({
      _id: new ObjectId(warehouseId),
    })

    if (!warehouse) {
      return NextResponse.json({ error: "Warehouse not found" }, { status: 404 })
    }

    // Calculate total price
    const totalPrice = warehouse.price * days

    // Create booking record
    const booking = await db.collection("bookings").insertOne({
      warehouseId: new ObjectId(warehouseId),
      userId: user._id,
      startDate: new Date(startDate),
      endDate: new Date(endDate),
      status: "CONFIRMED",
      paymentId: razorpay_payment_id,
      orderId: razorpay_order_id,
      totalPrice,
      days,
      createdAt: new Date(),
      updatedAt: new Date(),
    })

    // Send email notification (we'll implement this later)
    // await sendBookingConfirmation(user.email, user.name, {
    //   warehouseName: warehouse.name,
    //   startDate: new Date(startDate),
    //   endDate: new Date(endDate),
    //   amount: totalPrice,
    //   orderId: razorpay_order_id,
    // })

    return NextResponse.json({
      success: true,
      bookingId: booking.insertedId.toString(),
    })
  } catch (error) {
    console.error("Error verifying payment:", error)
    return NextResponse.json({ error: "Payment verification failed" }, { status: 500 })
  }
}

