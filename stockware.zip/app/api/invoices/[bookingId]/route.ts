import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"
import PDFDocument from "pdfkit"

export async function GET(request: Request, { params }: { params: { bookingId: string } }) {
  try {
    const session = await getServerSession()

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const client = await clientPromise
    const db = client.db("stockware")

    // Get user from session
    const user = await db.collection("users").findOne({ email: session.user.email })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Get booking details
    const booking = await db
      .collection("bookings")
      .aggregate([
        {
          $match: {
            _id: new ObjectId(params.bookingId),
            userId: user._id,
          },
        },
        {
          $lookup: {
            from: "warehouses",
            localField: "warehouseId",
            foreignField: "_id",
            as: "warehouse",
          },
        },
        {
          $unwind: "$warehouse",
        },
      ])
      .next()

    if (!booking) {
      return NextResponse.json({ error: "Booking not found" }, { status: 404 })
    }

    // Create PDF
    const doc = new PDFDocument({ margin: 50 })
    const chunks: Buffer[] = []

    doc.on("data", (chunk) => chunks.push(chunk))

    // Add company logo
    // doc.image("public/logo.png", 50, 45, { width: 50 })

    // Add company information
    doc
      .fontSize(20)
      .text("Stockware", 50, 50)
      .fontSize(10)
      .text("123 Warehouse Street", 50, 80)
      .text("Mumbai, India", 50, 95)
      .text("info@stockware.com", 50, 110)
      .text("+91 123 456 7890", 50, 125)

    // Add invoice information
    doc
      .fontSize(16)
      .text("INVOICE", 400, 50)
      .fontSize(10)
      .text(`Invoice Number: INV-${params.bookingId.substring(0, 8)}`, 400, 80)
      .text(`Invoice Date: ${new Date().toLocaleDateString()}`, 400, 95)
      .text(`Order ID: ${booking.orderId}`, 400, 110)
      .text(`Payment ID: ${booking.paymentId}`, 400, 125)

    // Add customer information
    doc
      .fontSize(14)
      .text("Bill To:", 50, 170)
      .fontSize(10)
      .text(user.name || "Customer", 50, 190)
      .text(user.email, 50, 205)
      .text(user.phone || "", 50, 220)

    // Add booking details
    doc
      .fontSize(14)
      .text("Booking Details:", 50, 260)
      .fontSize(10)
      .text(`Warehouse: ${booking.warehouse.name}`, 50, 280)
      .text(`Location: ${booking.warehouse.location}`, 50, 295)
      .text(`Type: ${booking.warehouse.type}`, 50, 310)
      .text(
        `Period: ${new Date(booking.startDate).toLocaleDateString()} to ${new Date(
          booking.endDate,
        ).toLocaleDateString()}`,
        50,
        325,
      )
      .text(`Duration: ${booking.days} days`, 50, 340)

    // Add table headers
    const invoiceTableTop = 380
    doc
      .fontSize(10)
      .text("Description", 50, invoiceTableTop)
      .text("Rate (₹/day)", 250, invoiceTableTop)
      .text("Days", 350, invoiceTableTop)
      .text("Amount (₹)", 450, invoiceTableTop)

    // Add line
    doc
      .moveTo(50, invoiceTableTop + 15)
      .lineTo(550, invoiceTableTop + 15)
      .stroke()

    // Add table row
    const invoiceTableRowTop = invoiceTableTop + 25
    doc
      .fontSize(10)
      .text(`Warehouse Booking - ${booking.warehouse.name}`, 50, invoiceTableRowTop)
      .text(`${(booking.totalPrice / booking.days).toLocaleString()}`, 250, invoiceTableRowTop)
      .text(`${booking.days}`, 350, invoiceTableRowTop)
      .text(`${booking.totalPrice.toLocaleString()}`, 450, invoiceTableRowTop)

    // Add line
    doc
      .moveTo(50, invoiceTableRowTop + 20)
      .lineTo(550, invoiceTableRowTop + 20)
      .stroke()

    // Add total
    doc
      .fontSize(10)
      .text("Total:", 350, invoiceTableRowTop + 35)
      .fontSize(12)
      .text(`₹${booking.totalPrice.toLocaleString()}`, 450, invoiceTableRowTop + 35)

    // Add payment status
    doc
      .fontSize(10)
      .text("Payment Status:", 350, invoiceTableRowTop + 55)
      .fontSize(12)
      .fillColor("green")
      .text("PAID", 450, invoiceTableRowTop + 55)
      .fillColor("black")

    // Add footer
    doc
      .fontSize(10)
      .text("Thank you for your business. For any queries, please contact support@stockware.com", 50, 700, {
        align: "center",
      })

    // Finalize PDF
    doc.end()

    return new Response(Buffer.concat(chunks), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="invoice-${params.bookingId}.pdf"`,
      },
    })
  } catch (error) {
    console.error("Error generating invoice:", error)
    return NextResponse.json({ error: "Failed to generate invoice" }, { status: 500 })
  }
}

