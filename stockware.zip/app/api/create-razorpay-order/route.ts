import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { razorpay } from "@/lib/razorpay"
import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function POST(request: Request) {
  try {
    const session = await getServerSession()

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { warehouseId, startDate, endDate, amount, days } = body

    // Validate input
    if (!warehouseId || !startDate || !endDate || !amount || !days) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const client = await clientPromise
    const db = client.db("stockware")

    // Get user from session
    const user = await db.collection("users").findOne({ email: session.user.email })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Verify warehouse exists
    const warehouse = await db.collection("warehouses").findOne({
      _id: new ObjectId(warehouseId),
    })

    if (!warehouse) {
      return NextResponse.json({ error: "Warehouse not found" }, { status: 404 })
    }

    // Check if warehouse is available for the selected dates
    const existingBooking = await db.collection("bookings").findOne({
      warehouseId: new ObjectId(warehouseId),
      status: "CONFIRMED",
      $or: [
        {
          startDate: { $lte: new Date(startDate) },
          endDate: { $gte: new Date(startDate) },
        },
        {
          startDate: { $lte: new Date(endDate) },
          endDate: { $gte: new Date(endDate) },
        },
        {
          startDate: { $gte: new Date(startDate) },
          endDate: { $lte: new Date(endDate) },
        },
      ],
    })

    if (existingBooking) {
      return NextResponse.json(
        {
          error: "Warehouse is not available for the selected dates",
        },
        { status: 400 },
      )
    }

    // Create Razorpay order
    const order = await razorpay.orders.create({
      amount: amount,
      currency: "INR",
      receipt: `booking_${warehouseId}_${user._id}_${Date.now()}`,
      notes: {
        warehouseId,
        userId: user._id.toString(),
        startDate,
        endDate,
        days,
      },
    })

    return NextResponse.json({
      orderId: order.id,
    })
  } catch (error) {
    console.error("Error creating Razorpay order:", error)
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 })
  }
}

