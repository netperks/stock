import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { ObjectId } from "mongodb"
import clientPromise from "@/lib/mongodb"

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession()

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const client = await clientPromise
    const db = client.db("stockware")

    const user = await db.collection("users").findOne({ email: session.user.email })

    if (!user || user.role !== "WAREHOUSE_OWNER") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const warehouseId = new ObjectId(params.id)

    // Check if the warehouse belongs to the user
    const warehouse = await db.collection("warehouses").findOne({
      _id: warehouseId,
      ownerId: user._id,
    })

    if (!warehouse) {
      return NextResponse.json({ error: "Warehouse not found or not owned by you" }, { status: 404 })
    }

    // Check if there are active bookings
    const activeBookings = await db.collection("bookings").countDocuments({
      warehouseId: warehouseId,
      status: "CONFIRMED",
      endDate: { $gte: new Date() },
    })

    if (activeBookings > 0) {
      return NextResponse.json({ error: "Cannot delete warehouse with active bookings" }, { status: 400 })
    }

    // Delete the warehouse
    await db.collection("warehouses").deleteOne({ _id: warehouseId })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting warehouse:", error)
    return NextResponse.json({ error: "Failed to delete warehouse" }, { status: 500 })
  }
}

