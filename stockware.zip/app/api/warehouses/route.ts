import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { ObjectId } from "mongodb"
import clientPromise from "@/lib/mongodb"

export async function POST(request: Request) {
  try {
    const session = await getServerSession()

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()

    const client = await clientPromise
    const db = client.db("stockware")

    const user = await db.collection("users").findOne({ email: session.user.email })

    if (!user || user.role !== "WAREHOUSE_OWNER") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const warehouse = await db.collection("warehouses").insertOne({
      ...body,
      ownerId: new ObjectId(body.ownerId),
      createdAt: new Date(),
      updatedAt: new Date(),
    })

    return NextResponse.json({
      success: true,
      warehouseId: warehouse.insertedId,
    })
  } catch (error) {
    console.error("Error creating warehouse:", error)
    return NextResponse.json({ error: "Failed to create warehouse" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)

    const location = searchParams.get("location")
    const type = searchParams.get("type")
    const minPrice = searchParams.get("minPrice")
    const maxPrice = searchParams.get("maxPrice")
    const minCapacity = searchParams.get("minCapacity")

    const query: any = {}

    if (location) {
      query.location = { $regex: location, $options: "i" }
    }

    if (type) {
      query.type = type
    }

    if (minPrice || maxPrice) {
      query.price = {}
      if (minPrice) query.price.$gte = Number.parseFloat(minPrice)
      if (maxPrice) query.price.$lte = Number.parseFloat(maxPrice)
    }

    if (minCapacity) {
      query.capacity = { $gte: Number.parseInt(minCapacity) }
    }

    const client = await clientPromise
    const db = client.db("stockware")

    const warehouses = await db.collection("warehouses").find(query).sort({ createdAt: -1 }).limit(20).toArray()

    return NextResponse.json(warehouses)
  } catch (error) {
    console.error("Error fetching warehouses:", error)
    return NextResponse.json({ error: "Failed to fetch warehouses" }, { status: 500 })
  }
}

