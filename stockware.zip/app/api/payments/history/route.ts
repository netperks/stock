import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import clientPromise from "@/lib/mongodb"

export async function GET(request: Request) {
  try {
    const session = await getServerSession()

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const client = await clientPromise
    const db = client.db("stockware")

    const user = await db.collection("users").findOne({ email: session.user.email })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const bookings = await db
      .collection("bookings")
      .aggregate([
        { $match: { userId: user._id } },
        {
          $lookup: {
            from: "warehouses",
            localField: "warehouseId",
            foreignField: "_id",
            as: "warehouse",
          },
        },
        { $unwind: "$warehouse" },
        { $sort: { createdAt: -1 } },
      ])
      .toArray()

    const payments = bookings.map((booking) => ({
      id: booking._id.toString(),
      amount: booking.totalPrice,
      status: booking.status,
      createdAt: booking.createdAt,
      orderId: booking.orderId,
      paymentId: booking.paymentId,
      warehouseName: booking.warehouse.name,
    }))

    return NextResponse.json(payments)
  } catch (error) {
    console.error("Error fetching payment history:", error)
    return NextResponse.json({ error: "Failed to fetch payment history" }, { status: 500 })
  }
}

