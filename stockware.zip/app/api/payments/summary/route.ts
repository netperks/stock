import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import clientPromise from "@/lib/mongodb"

export async function GET(request: Request) {
  try {
    const session = await getServerSession()

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const client = await clientPromise
    const db = client.db("stockware")

    const user = await db.collection("users").findOne({ email: session.user.email })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const now = new Date()

    const [totalSpentResult, activeBookings, upcomingBookings] = await Promise.all([
      // Calculate total spent
      db
        .collection("bookings")
        .aggregate([
          { $match: { userId: user._id, status: "CONFIRMED" } },
          { $group: { _id: null, total: { $sum: "$totalPrice" } } },
        ])
        .toArray(),

      // Count active bookings
      db
        .collection("bookings")
        .countDocuments({
          userId: user._id,
          status: "CONFIRMED",
          startDate: { $lte: now },
          endDate: { $gte: now },
        }),

      // Count upcoming bookings
      db
        .collection("bookings")
        .countDocuments({
          userId: user._id,
          status: "CONFIRMED",
          startDate: { $gt: now },
        }),
    ])

    const totalSpent = totalSpentResult[0]?.total || 0

    return NextResponse.json({
      totalSpent,
      activeBookings,
      upcomingBookings,
    })
  } catch (error) {
    console.error("Error fetching payment summary:", error)
    return NextResponse.json({ error: "Failed to fetch payment summary" }, { status: 500 })
  }
}

