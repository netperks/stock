import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { ObjectId } from "mongodb"
import clientPromise from "@/lib/mongodb"
import PDFDocument from "pdfkit"

export async function GET(request: Request, { params }: { params: { paymentId: string } }) {
  try {
    const session = await getServerSession()

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const client = await clientPromise
    const db = client.db("stockware")

    const booking = await db
      .collection("bookings")
      .aggregate([
        { $match: { _id: new ObjectId(params.paymentId) } },
        {
          $lookup: {
            from: "warehouses",
            localField: "warehouseId",
            foreignField: "_id",
            as: "warehouse",
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "user",
          },
        },
        { $unwind: "$warehouse" },
        { $unwind: "$user" },
      ])
      .next()

    if (!booking) {
      return NextResponse.json({ error: "Booking not found" }, { status: 404 })
    }

    // Create PDF
    const doc = new PDFDocument()
    const chunks: Buffer[] = []

    doc.on("data", (chunk) => chunks.push(chunk))

    // Add content to PDF
    doc
      .fontSize(20)
      .text("Stockware - Invoice", { align: "center" })
      .moveDown()
      .fontSize(12)
      .text(`Invoice Date: ${new Date().toLocaleDateString()}`)
      .text(`Order ID: ${booking.orderId}`)
      .moveDown()
      .text("Bill To:")
      .text(booking.user.name || "N/A")
      .text(booking.user.email || "N/A")
      .moveDown()
      .text("Warehouse Details:")
      .text(booking.warehouse.name)
      .text(booking.warehouse.location)
      .moveDown()
      .text("Booking Period:")
      .text(`From: ${booking.startDate.toLocaleDateString()}`)
      .text(`To: ${booking.endDate.toLocaleDateString()}`)
      .moveDown()
      .text(`Total Amount: ₹${booking.totalPrice}`)
      .moveDown()
      .text("Thank you for choosing Stockware!")
      .end()

    return new Response(Buffer.concat(chunks), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="invoice-${params.paymentId}.pdf"`,
      },
    })
  } catch (error) {
    console.error("Error generating invoice:", error)
    return NextResponse.json({ error: "Failed to generate invoice" }, { status: 500 })
  }
}

