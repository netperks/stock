import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { stripe } from "@/lib/stripe"

const prisma = new PrismaClient()

export async function POST(request: Request) {
  const body = await request.json()
  const { warehouseId, startDate, endDate, userId } = body

  const warehouse = await prisma.warehouse.findUnique({
    where: { id: warehouseId },
  })

  if (!warehouse) {
    return NextResponse.json({ error: "Warehouse not found" }, { status: 404 })
  }

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency: "usd",
          product_data: {
            name: warehouse.name,
          },
          unit_amount: Math.round(warehouse.price * 100), // Stripe expects amounts in cents
        },
        quantity: 1,
      },
    ],
    mode: "payment",
    success_url: `${process.env.NEXT_PUBLIC_URL}/booking-success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.NEXT_PUBLIC_URL}/warehouses/${warehouseId}`,
    metadata: {
      warehouseId,
      startDate,
      endDate,
      userId,
    },
  })

  return NextResponse.json({ sessionId: session.id })
}

