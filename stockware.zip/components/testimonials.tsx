import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { StarIcon } from "lucide-react"

const testimonials = [
  {
    id: 1,
    name: "Rajesh Kumar",
    company: "ABC Logistics",
    testimonial:
      "Stockware has revolutionized our warehouse management. The AI-powered forecasting is a game-changer for our inventory planning!",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
  },
  {
    id: 2,
    name: "Priya Sharma",
    company: "XYZ Enterprises",
    testimonial:
      "Finding the right warehouse space has never been easier. Stockware saved us time and money with their seamless booking process.",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
  },
  {
    id: 3,
    name: "Amit Patel",
    company: "Global Shipping Co.",
    testimonial:
      "The real-time tracking and analytics have improved our operational efficiency by 30%. Highly recommend Stockware for any business.",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 4,
  },
]

export function Testimonials() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {testimonials.map((testimonial) => (
        <Card key={testimonial.id} className="h-full flex flex-col">
          <CardContent className="pt-6 flex-grow">
            <div className="flex mb-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <StarIcon
                  key={i}
                  className={`h-4 w-4 ${i < testimonial.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
                />
              ))}
            </div>
            <p className="italic">"{testimonial.testimonial}"</p>
          </CardContent>
          <CardFooter className="flex items-center gap-4 border-t pt-4">
            <Avatar>
              <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
              <AvatarFallback>
                {testimonial.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold">{testimonial.name}</p>
              <p className="text-sm text-muted-foreground">{testimonial.company}</p>
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

