import { WarehouseCard } from "@/components/warehouse-card"
import { filterWarehouses } from "@/lib/mock-data"

export function WarehouseList({
  filters = {},
}: {
  filters?: Record<string, any>
}) {
  const warehouses = filterWarehouses(filters)

  if (warehouses.length === 0) {
    return (
      <div className="text-center py-12 bg-muted rounded-lg">
        <h3 className="text-lg font-medium">No warehouses found</h3>
        <p className="text-muted-foreground mt-2">Try adjusting your filters or check back later.</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {warehouses.map((warehouse) => (
        <WarehouseCard key={warehouse.id} warehouse={warehouse} />
      ))}
    </div>
  )
}

