"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search } from "lucide-react"

export function SearchBar() {
  const [location, setLocation] = useState("")
  const [warehouseType, setWarehouseType] = useState("")
  const router = useRouter()

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    const searchParams = new URLSearchParams()
    if (location) searchParams.append("location", location)
    if (warehouseType) searchParams.append("type", warehouseType)
    router.push(`/warehouses?${searchParams.toString()}`)
  }

  return (
    <form onSubmit={handleSearch} className="w-full max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            type="text"
            placeholder="Location (City, State, or ZIP)"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={warehouseType} onValueChange={setWarehouseType}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Warehouse Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Types</SelectItem>
            <SelectItem value="DRY_STORAGE">Dry Storage</SelectItem>
            <SelectItem value="COLD_STORAGE">Cold Storage</SelectItem>
            <SelectItem value="HAZARDOUS_MATERIALS">Hazardous Materials</SelectItem>
          </SelectContent>
        </Select>
        <Button type="submit" className="md:w-auto">
          <Search className="h-4 w-4 mr-2" />
          Search
        </Button>
      </div>
    </form>
  )
}

