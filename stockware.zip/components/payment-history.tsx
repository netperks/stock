"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PaymentStatusBadge } from "@/components/payment-status-badge"
import { PaymentReceipt } from "@/components/payment-receipt"
import { Loader2 } from "lucide-react"

interface Payment {
  id: string
  amount: number
  status: "PENDING" | "CONFIRMED" | "CANCELLED" | "FAILED"
  createdAt: string
  orderId: string
  paymentId: string
  warehouseName: string
}

export function PaymentHistory() {
  const [payments, setPayments] = useState<Payment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchPayments()
  }, [])

  const fetchPayments = async () => {
    try {
      const response = await fetch("/api/payments/history")
      if (response.ok) {
        const data = await response.json()
        setPayments(data)
      }
    } catch (error) {
      console.error("Error fetching payments:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-6">
          <Loader2 className="h-6 w-6 animate-spin" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payment History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {payments.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">No payment history available</p>
          ) : (
            payments.map((payment) => (
              <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-1">
                  <h3 className="font-semibold">{payment.warehouseName}</h3>
                  <p className="text-sm text-muted-foreground">{new Date(payment.createdAt).toLocaleDateString()}</p>
                  <PaymentStatusBadge status={payment.status} />
                </div>
                <div className="flex flex-col items-end gap-2">
                  <p className="font-semibold">₹{payment.amount}</p>
                  <PaymentReceipt
                    paymentId={payment.id}
                    orderId={payment.orderId}
                    paymentId={payment.paymentId}
                    amount={payment.amount}
                    date={payment.createdAt}
                    warehouseName={payment.warehouseName}
                  />
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}

