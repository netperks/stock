import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MapPin, ArrowRight } from "lucide-react"
import { warehouses } from "@/lib/mock-data"

export function FeaturedListings() {
  // Use the first 3 warehouses from our mock data
  const featuredWarehouses = warehouses.slice(0, 3)

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {featuredWarehouses.map((warehouse) => (
        <Card key={warehouse.id} className="overflow-hidden hover:shadow-lg transition-shadow">
          <CardHeader className="p-0">
            <div className="relative h-48 w-full">
              <Image
                src={warehouse.imageUrl || "/placeholder.svg?height=200&width=300"}
                alt={warehouse.name}
                fill
                className="object-cover"
              />
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <h3 className="text-xl font-semibold mb-1">{warehouse.name}</h3>
            <div className="flex items-center text-muted-foreground mb-2">
              <MapPin className="h-4 w-4 mr-1" />
              <span className="text-sm">{warehouse.location}</span>
            </div>
            <div className="flex flex-wrap gap-2 mb-2">
              <Badge variant="outline">{warehouse.type.replace("_", " ")}</Badge>
              <Badge variant="outline">{warehouse.capacity} sq ft</Badge>
            </div>
            <p className="font-bold text-lg">₹{warehouse.price.toLocaleString()}/month</p>
          </CardContent>
          <CardFooter className="p-4 pt-0">
            <Button asChild className="w-full">
              <Link href={`/warehouses/${warehouse.id}`}>
                View Details <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

