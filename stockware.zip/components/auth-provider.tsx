"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { users } from "@/lib/mock-data"

type User = {
  id: string
  name: string
  email: string
  role: string
  image: string | null
}

type AuthContextType = {
  user: User | null
  status: "loading" | "authenticated" | "unauthenticated"
  signIn: (email: string) => void
  signOut: () => void
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  status: "unauthenticated",
  signIn: () => {},
  signOut: () => {},
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [status, setStatus] = useState<"loading" | "authenticated" | "unauthenticated">("loading")

  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem("stockware-user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
      setStatus("authenticated")
    } else {
      setStatus("unauthenticated")
    }
  }, [])

  const signIn = (email: string) => {
    const foundUser = users.find((u) => u.email === email)
    if (foundUser) {
      setUser(foundUser)
      setStatus("authenticated")
      localStorage.setItem("stockware-user", JSON.stringify(foundUser))
    }
  }

  const signOut = () => {
    setUser(null)
    setStatus("unauthenticated")
    localStorage.removeItem("stockware-user")
  }

  return <AuthContext.Provider value={{ user, status, signIn, signOut }}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)

