"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"

export function InventoryManagement({ warehouses }) {
  const [selectedWarehouse, setSelectedWarehouse] = useState("")
  const [itemName, setItemName] = useState("")
  const [quantity, setQuantity] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch("/api/inventory", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        warehouseId: selectedWarehouse,
        itemName,
        quantity: Number.parseInt(quantity),
      }),
    })

    if (response.ok) {
      toast({
        title: "Inventory updated successfully",
      })
      setItemName("")
      setQuantity("")
    } else {
      toast({
        title: "Error updating inventory",
        variant: "destructive",
      })
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Select value={selectedWarehouse} onValueChange={setSelectedWarehouse}>
        <option value="">Select Warehouse</option>
        {warehouses.map((warehouse) => (
          <option key={warehouse.id} value={warehouse.id}>
            {warehouse.name}
          </option>
        ))}
      </Select>
      <Input
        type="text"
        placeholder="Item Name"
        value={itemName}
        onChange={(e) => setItemName(e.target.value)}
        required
      />
      <Input
        type="number"
        placeholder="Quantity"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
        required
      />
      <Button type="submit">Update Inventory</Button>
    </form>
  )
}

