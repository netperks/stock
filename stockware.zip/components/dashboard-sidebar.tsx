"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { LayoutDashboard, Warehouse, Package, Calendar, CreditCard, Settings, LogOut, Menu, X } from "lucide-react"

export function DashboardSidebar({ user }: { user: any }) {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)
  const { signOut } = useAuth()

  const userRole = user.role || "BUSINESS"

  const routes = [
    {
      label: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
      active: pathname === "/dashboard",
    },
  ]

  if (userRole === "WAREHOUSE_OWNER") {
    routes.push(
      {
        label: "My Warehouses",
        href: "/dashboard/warehouses",
        icon: Warehouse,
        active: pathname === "/dashboard/warehouses",
      },
      {
        label: "Add Warehouse",
        href: "/dashboard/warehouses/add",
        icon: Package,
        active: pathname === "/dashboard/warehouses/add",
      },
    )
  }

  if (userRole === "BUSINESS" || userRole === "LOGISTICS_PROVIDER") {
    routes.push({
      label: "My Bookings",
      href: "/dashboard/bookings",
      icon: Calendar,
      active: pathname === "/dashboard/bookings",
    })
  }

  routes.push(
    {
      label: "Payments",
      href: "/dashboard/payments",
      icon: CreditCard,
      active: pathname === "/dashboard/payments",
    },
    {
      label: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
      active: pathname === "/dashboard/settings",
    },
  )

  return (
    <>
      {/* Mobile Sidebar Toggle */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-30 bg-background border-b p-4 flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <Warehouse className="h-6 w-6" />
          <span className="font-bold text-xl">Stockware</span>
        </Link>
        <Button variant="ghost" size="icon" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {/* Sidebar */}
      <aside
        className={`
        fixed top-0 left-0 z-40 h-screen w-64 bg-card border-r transition-transform
        md:translate-x-0 md:top-0 pt-0 md:pt-4
        ${isOpen ? "translate-x-0" : "-translate-x-full"}
      `}
      >
        <div className="h-full flex flex-col overflow-y-auto">
          <div className="px-4 py-6 border-b">
            <div className="flex items-center space-x-3">
              <Avatar>
                <AvatarImage src={user.image || ""} alt={user.name || ""} />
                <AvatarFallback>{user.name?.charAt(0) || user.email?.charAt(0) || "U"}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{user.name || "User"}</p>
                <p className="text-xs text-muted-foreground">{userRole.replace("_", " ")}</p>
              </div>
            </div>
          </div>

          <nav className="flex-1 px-3 py-4 space-y-1">
            {routes.map((route) => (
              <Link
                key={route.href}
                href={route.href}
                className={`
                  flex items-center px-3 py-2 text-sm rounded-md
                  ${
                    route.active
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }
                `}
                onClick={() => setIsOpen(false)}
              >
                <route.icon className="mr-3 h-5 w-5" />
                {route.label}
              </Link>
            ))}
          </nav>

          <div className="px-3 py-4 border-t">
            <Button
              variant="ghost"
              className="w-full justify-start text-muted-foreground hover:text-foreground"
              onClick={signOut}
            >
              <LogOut className="mr-3 h-5 w-5" />
              Log out
            </Button>
          </div>
        </div>
      </aside>

      {/* Overlay */}
      {isOpen && <div className="fixed inset-0 z-30 bg-black/50 md:hidden" onClick={() => setIsOpen(false)} />}
    </>
  )
}

