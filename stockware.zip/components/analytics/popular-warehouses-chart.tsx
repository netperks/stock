"use client"

import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Legend, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface PopularWarehousesChartProps {
  data: Array<{
    name: string
    bookings: number
  }>
}

export function PopularWarehousesChart({ data }: PopularWarehousesChartProps) {
  return (
    <ChartContainer
      config={{
        bookings: {
          label: "Number of Bookings",
          color: "hsl(var(--chart-4))",
        },
      }}
      className="h-full w-full"
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          layout="vertical"
          margin={{
            top: 5,
            right: 30,
            left: 120,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" />
          <YAxis type="category" dataKey="name" />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Legend />
          <Bar dataKey="bookings" fill="var(--color-bookings)" />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

