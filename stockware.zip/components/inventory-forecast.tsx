"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, TrendingDown, AlertTriangle } from "lucide-react"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, Legend, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { toast } from "@/components/ui/use-toast"

interface InventoryForecastProps {
  warehouses: Array<{
    id: string
    name: string
  }>
}

export function InventoryForecast({ warehouses }: InventoryForecastProps) {
  const [selectedWarehouse, setSelectedWarehouse] = useState("")
  const [forecastPeriod, setForecastPeriod] = useState("30")
  const [loading, setLoading] = useState(false)
  const [forecastData, setForecastData] = useState<any>(null)
  const [inventoryItems, setInventoryItems] = useState<string[]>([])
  const [selectedItem, setSelectedItem] = useState("")

  useEffect(() => {
    if (selectedWarehouse) {
      fetchInventoryItems()
    }
  }, [selectedWarehouse])

  const fetchInventoryItems = async () => {
    try {
      setLoading(true)
      // In a real app, we would fetch from the API
      // const response = await fetch(`/api/inventory/items?warehouseId=${selectedWarehouse}`)
      // if (response.ok) {
      //   const data = await response.json()
      //   setInventoryItems(data.items)
      // }

      // For demo purposes, let's create mock inventory items
      setTimeout(() => {
        setInventoryItems(["Electronics", "Furniture", "Clothing", "Food Products", "Pharmaceuticals"])
        setLoading(false)
      }, 500)
    } catch (error) {
      console.error("Error fetching inventory items:", error)
      setLoading(false)
    }
  }

  const generateForecast = async () => {
    if (!selectedWarehouse || !selectedItem) {
      toast({
        title: "Please select a warehouse and inventory item",
        variant: "destructive",
      })
      return
    }

    try {
      setLoading(true)
      // In a real app, we would fetch from the API
      // const response = await fetch(`/api/inventory-forecast?warehouseId=${selectedWarehouse}&item=${selectedItem}&period=${forecastPeriod}`)
      // if (response.ok) {
      //   const data = await response.json()
      //   setForecastData(data)
      // }

      // For demo purposes, let's create mock forecast data
      setTimeout(() => {
        const data = generateMockForecastData(Number.parseInt(forecastPeriod))
        setForecastData({
          item: selectedItem,
          warehouseName: warehouses.find((w) => w.id === selectedWarehouse)?.name,
          currentStock: Math.floor(Math.random() * 500) + 100,
          forecastedDemand: Math.floor(Math.random() * 400) + 50,
          recommendedRestock: Math.floor(Math.random() * 300) + 50,
          stockoutRisk: Math.random() < 0.3 ? "High" : Math.random() < 0.7 ? "Medium" : "Low",
          data,
        })
        setLoading(false)
      }, 1500)
    } catch (error) {
      console.error("Error generating forecast:", error)
      setLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>AI-Powered Inventory Forecasting</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Warehouse</label>
              <Select value={selectedWarehouse} onValueChange={setSelectedWarehouse}>
                <SelectTrigger>
                  <SelectValue placeholder="Select warehouse" />
                </SelectTrigger>
                <SelectContent>
                  {warehouses.map((warehouse) => (
                    <SelectItem key={warehouse.id} value={warehouse.id}>
                      {warehouse.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Inventory Item</label>
              <Select value={selectedItem} onValueChange={setSelectedItem} disabled={!selectedWarehouse || loading}>
                <SelectTrigger>
                  <SelectValue placeholder="Select item" />
                </SelectTrigger>
                <SelectContent>
                  {inventoryItems.map((item) => (
                    <SelectItem key={item} value={item}>
                      {item}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Forecast Period (Days)</label>
              <Select value={forecastPeriod} onValueChange={setForecastPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 days</SelectItem>
                  <SelectItem value="14">14 days</SelectItem>
                  <SelectItem value="30">30 days</SelectItem>
                  <SelectItem value="60">60 days</SelectItem>
                  <SelectItem value="90">90 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button
            onClick={generateForecast}
            disabled={!selectedWarehouse || !selectedItem || loading}
            className="w-full"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Forecast...
              </>
            ) : (
              "Generate Forecast"
            )}
          </Button>

          {forecastData && (
            <div className="mt-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-sm font-medium text-muted-foreground mb-1">Current Stock</div>
                    <div className="text-2xl font-bold">{forecastData.currentStock} units</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-sm font-medium text-muted-foreground mb-1">Forecasted Demand</div>
                    <div className="text-2xl font-bold">{forecastData.forecastedDemand} units</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-sm font-medium text-muted-foreground mb-1">Recommended Restock</div>
                    <div className="text-2xl font-bold">{forecastData.recommendedRestock} units</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-sm font-medium text-muted-foreground mb-1">Stockout Risk</div>
                    <div className="flex items-center">
                      <div className="text-2xl font-bold mr-2">{forecastData.stockoutRisk}</div>
                      {forecastData.stockoutRisk === "High" && <AlertTriangle className="h-5 w-5 text-red-500" />}
                      {forecastData.stockoutRisk === "Medium" && <AlertTriangle className="h-5 w-5 text-yellow-500" />}
                      {forecastData.stockoutRisk === "Low" && <TrendingDown className="h-5 w-5 text-green-500" />}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Inventory Forecast for {forecastData.item}</CardTitle>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ChartContainer
                    config={{
                      projected: {
                        label: "Projected Inventory",
                        color: "hsl(var(--chart-1))",
                      },
                      demand: {
                        label: "Projected Demand",
                        color: "hsl(var(--chart-2))",
                      },
                      restock: {
                        label: "Recommended Restock",
                        color: "hsl(var(--chart-3))",
                      },
                    }}
                    className="h-full w-full"
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={forecastData.data}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                          dataKey="date"
                          tickFormatter={(value) => {
                            const date = new Date(value)
                            return `${date.getDate()}/${date.getMonth() + 1}`
                          }}
                        />
                        <YAxis />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Legend />
                        <Line type="monotone" dataKey="projected" stroke="var(--color-projected)" strokeWidth={2} />
                        <Line type="monotone" dataKey="demand" stroke="var(--color-demand)" strokeWidth={2} />
                        <Line
                          type="monotone"
                          dataKey="restock"
                          stroke="var(--color-restock)"
                          strokeDasharray="5 5"
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>AI Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p>
                      Based on historical data and current trends, our AI recommends the following actions for{" "}
                      {forecastData.item} at {forecastData.warehouseName}:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      {forecastData.stockoutRisk === "High" && (
                        <>
                          <li className="text-red-500">
                            <strong>Urgent Restock Required:</strong> Current inventory levels are projected to be
                            insufficient to meet demand. Order {forecastData.recommendedRestock} units within the next 7
                            days to avoid stockouts.
                          </li>
                          <li>
                            Consider increasing safety stock levels by 20% to account for seasonal demand fluctuations.
                          </li>
                        </>
                      )}
                      {forecastData.stockoutRisk === "Medium" && (
                        <>
                          <li className="text-yellow-500">
                            <strong>Monitor Inventory Closely:</strong> Current inventory may be sufficient, but restock
                            of {forecastData.recommendedRestock} units is recommended within the next 14 days.
                          </li>
                          <li>Review supplier lead times to ensure timely delivery of new stock.</li>
                        </>
                      )}
                      {forecastData.stockoutRisk === "Low" && (
                        <>
                          <li className="text-green-500">
                            <strong>Inventory Levels Optimal:</strong> Current inventory is projected to meet demand for
                            the forecasted period.
                          </li>
                          <li>
                            Consider optimizing warehouse space by redistributing excess inventory to other locations if
                            applicable.
                          </li>
                        </>
                      )}
                      <li>
                        Based on historical data, demand for {forecastData.item} is expected to{" "}
                        {Math.random() < 0.5 ? "increase" : "decrease"} by {Math.floor(Math.random() * 15) + 5}% in the
                        coming month.
                      </li>
                      <li>
                        Optimize inventory turnover by implementing a{" "}
                        {Math.random() < 0.5 ? "First-In-First-Out (FIFO)" : "Last-In-First-Out (LIFO)"} strategy for
                        this product category.
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

// Helper function to generate mock forecast data
function generateMockForecastData(days: number) {
  const data = []
  const now = new Date()
  const currentStock = Math.floor(Math.random() * 500) + 100

  let projectedStock = currentStock
  const restockPoint = Math.floor(days / 2)
  const restockAmount = Math.floor(Math.random() * 300) + 50

  for (let i = 0; i < days; i++) {
    const date = new Date(now)
    date.setDate(date.getDate() + i)

    // Daily demand varies between 5-15 units
    const dailyDemand = Math.floor(Math.random() * 10) + 5

    // If we've reached the restock point, add the restock amount
    if (i === restockPoint) {
      projectedStock += restockAmount
    }

    // Subtract daily demand
    projectedStock -= dailyDemand

    // Ensure projected stock doesn't go below 0
    projectedStock = Math.max(0, projectedStock)

    data.push({
      date: date.toISOString().split("T")[0],
      projected: projectedStock,
      demand: currentStock - dailyDemand * (i + 1),
      restock: i >= restockPoint ? null : 0,
    })

    // Add restock line
    if (i === restockPoint) {
      data[i].restock = projectedStock
    }
  }

  return data
}

