import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Warehouse, Building, DollarSign, Users } from "lucide-react"
import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function WarehouseOwnerStats({ userId }: { userId: string }) {
  const client = await clientPromise
  const db = client.db("stockware")

  const [warehouseCount, totalBookings, totalRevenue, activeBookings] = await Promise.all([
    // Count total warehouses
    db
      .collection("warehouses")
      .countDocuments({ ownerId: new ObjectId(userId) }),

    // Count total bookings
    db
      .collection("bookings")
      .countDocuments({
        warehouseId: {
          $in: await db
            .collection("warehouses")
            .find({ ownerId: new ObjectId(userId) })
            .map((w) => w._id)
            .toArray(),
        },
      }),

    // Calculate total revenue
    db
      .collection("bookings")
      .aggregate([
        {
          $match: {
            warehouseId: {
              $in: await db
                .collection("warehouses")
                .find({ ownerId: new ObjectId(userId) })
                .map((w) => w._id)
                .toArray(),
            },
            status: "CONFIRMED",
          },
        },
        { $group: { _id: null, total: { $sum: "$totalPrice" } } },
      ])
      .toArray()
      .then((result) => result[0]?.total || 0),

    // Count active bookings
    db
      .collection("bookings")
      .countDocuments({
        warehouseId: {
          $in: await db
            .collection("warehouses")
            .find({ ownerId: new ObjectId(userId) })
            .map((w) => w._id)
            .toArray(),
        },
        status: "CONFIRMED",
        startDate: { $lte: new Date() },
        endDate: { $gte: new Date() },
      }),
  ])

  const stats = [
    {
      title: "Total Warehouses",
      value: warehouseCount,
      icon: Warehouse,
      color: "text-blue-500",
      bgColor: "bg-blue-100",
    },
    {
      title: "Total Bookings",
      value: totalBookings,
      icon: Building,
      color: "text-green-500",
      bgColor: "bg-green-100",
    },
    {
      title: "Total Revenue",
      value: `₹${totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: "text-purple-500",
      bgColor: "bg-purple-100",
    },
    {
      title: "Active Bookings",
      value: activeBookings,
      icon: Users,
      color: "text-orange-500",
      bgColor: "bg-orange-100",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
            <div className={`p-2 rounded-full ${stat.bgColor}`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

