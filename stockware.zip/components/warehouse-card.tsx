import Image from "next/image"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { MapPin } from "lucide-react"

interface WarehouseCardProps {
  warehouse: {
    id: string
    name: string
    location: string
    type: string
    price: number
    imageUrl?: string
  }
}

export function WarehouseCard({ warehouse }: WarehouseCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative h-48 w-full">
        <Image
          src={warehouse.imageUrl || "/placeholder.svg?height=200&width=300"}
          alt={warehouse.name}
          fill
          className="object-cover"
        />
      </div>
      <CardContent className="p-4">
        <h3 className="text-xl font-semibold mb-1">{warehouse.name}</h3>
        <div className="flex items-center text-muted-foreground mb-2">
          <MapPin className="h-4 w-4 mr-1" />
          <span className="text-sm">{warehouse.location}</span>
        </div>
        <Badge variant="outline">{warehouse.type}</Badge>
      </CardContent>
      <CardFooter className="flex justify-between p-4 pt-0">
        <span className="font-bold text-lg">₹{warehouse.price.toLocaleString()}/month</span>
        <Button asChild size="sm">
          <Link href={`/warehouses/${warehouse.id}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

