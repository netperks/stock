import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, Clock } from "lucide-react"

interface PaymentStatusBadgeProps {
  status: "PENDING" | "CONFIRMED" | "CANCELLED" | "FAILED"
}

export function PaymentStatusBadge({ status }: PaymentStatusBadgeProps) {
  const statusConfig = {
    PENDING: {
      color: "bg-yellow-100 text-yellow-800",
      icon: Clock,
    },
    CONFIRMED: {
      color: "bg-green-100 text-green-800",
      icon: CheckCircle,
    },
    CANCELLED: {
      color: "bg-red-100 text-red-800",
      icon: XCircle,
    },
    FAILED: {
      color: "bg-red-100 text-red-800",
      icon: XCircle,
    },
  }

  const { color, icon: Icon } = statusConfig[status]

  return (
    <Badge className={`flex items-center gap-1 ${color}`}>
      <Icon className="h-4 w-4" />
      {status}
    </Badge>
  )
}

