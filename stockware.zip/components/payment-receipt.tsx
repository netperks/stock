"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Receipt, Download } from "lucide-react"

interface PaymentReceiptProps {
  paymentId: string
  orderId: string
  amount: number
  date: string
  warehouseName: string
}

export function PaymentReceipt({ paymentId, orderId, amount, date, warehouseName }: PaymentReceiptProps) {
  const [isOpen, setIsOpen] = useState(false)

  const handleDownload = async () => {
    try {
      const response = await fetch(`/api/payments/invoice/${paymentId}`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `invoice-${paymentId}.pdf`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      }
    } catch (error) {
      console.error("Error downloading receipt:", error)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Receipt className="h-4 w-4 mr-2" />
          View Receipt
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Payment Receipt</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="p-4 bg-muted rounded-lg">
            <h3 className="font-semibold text-lg mb-4">{warehouseName}</h3>
            <div className="space-y-2 text-sm">
              <p>
                <span className="font-medium">Order ID:</span> {orderId}
              </p>
              <p>
                <span className="font-medium">Payment ID:</span> {paymentId}
              </p>
              <p>
                <span className="font-medium">Amount:</span> ₹{amount}
              </p>
              <p>
                <span className="font-medium">Date:</span> {new Date(date).toLocaleDateString()}
              </p>
            </div>
          </div>
          <Button onClick={handleDownload} className="w-full">
            <Download className="h-4 w-4 mr-2" />
            Download Invoice
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

