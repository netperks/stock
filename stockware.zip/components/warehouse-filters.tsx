"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"

export function WarehouseFilters() {
  const [location, setLocation] = useState("")
  const [type, setType] = useState("")
  const [minPrice, setMinPrice] = useState("")
  const [maxPrice, setMaxPrice] = useState("")

  const handleFilter = () => {
    // In a real app, this would update the URL or trigger a data fetch
    console.log({ location, type, minPrice, maxPrice })
  }

  const handleReset = () => {
    setLocation("")
    setType("")
    setMinPrice("")
    setMaxPrice("")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Filters</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            placeholder="City, State, or ZIP"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="type">Warehouse Type</Label>
          <Select id="type" value={type} onChange={(e) => setType(e.target.value)} className="w-full">
            <option value="">All Types</option>
            <option value="Dry Storage">Dry Storage</option>
            <option value="Cold Storage">Cold Storage</option>
            <option value="Hazardous Materials">Hazardous Materials</option>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="price-range">Price Range (₹/month)</Label>
          <div className="flex items-center gap-2">
            <Input
              id="min-price"
              placeholder="Min"
              type="number"
              value={minPrice}
              onChange={(e) => setMinPrice(e.target.value)}
            />
            <span>to</span>
            <Input
              id="max-price"
              placeholder="Max"
              type="number"
              value={maxPrice}
              onChange={(e) => setMaxPrice(e.target.value)}
            />
          </div>
        </div>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleFilter}>Apply Filters</Button>
          <Button variant="outline" onClick={handleReset}>
            Reset Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

