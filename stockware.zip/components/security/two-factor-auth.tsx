"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Loader2, Shield, ShieldAlert, ShieldCheck } from "lucide-react"

export function TwoFactorAuth() {
  const [enabled, setEnabled] = useState(false)
  const [showSetup, setShowSetup] = useState(false)
  const [verificationCode, setVerificationCode] = useState("")
  const [loading, setLoading] = useState(false)
  const [qrCode, setQrCode] = useState<string | null>(null)
  const [secret, setSecret] = useState<string | null>(null)

  const handleToggle = async (checked: boolean) => {
    if (checked && !enabled) {
      // Enable 2FA
      setShowSetup(true)
      await generateSecret()
    } else if (!checked && enabled) {
      // Disable 2FA
      setLoading(true)
      try {
        // In a real app, we would call an API to disable 2FA
        // await fetch("/api/user/2fa/disable", { method: "POST" })

        // For demo purposes, just simulate the API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        setEnabled(false)
        setShowSetup(false)
        setQrCode(null)
        setSecret(null)

        toast({
          title: "Two-factor authentication disabled",
          description: "Your account is now less secure. We recommend enabling 2FA for better security.",
        })
      } catch (error) {
        console.error("Error disabling 2FA:", error)
        toast({
          title: "Error disabling two-factor authentication",
          description: "Please try again later.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }
  }

  const generateSecret = async () => {
    setLoading(true)
    try {
      // In a real app, we would call an API to generate a secret and QR code
      // const response = await fetch("/api/user/2fa/setup", { method: "POST" })
      // const data = await response.json()
      // setQrCode(data.qrCode)
      // setSecret(data.secret)

      // For demo purposes, just simulate the API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Mock QR code and secret
      setQrCode("/placeholder.svg?height=200&width=200")
      setSecret("ABCDEF123456")
    } catch (error) {
      console.error("Error generating 2FA secret:", error)
      toast({
        title: "Error setting up two-factor authentication",
        description: "Please try again later.",
        variant: "destructive",
      })
      setShowSetup(false)
    } finally {
      setLoading(false)
    }
  }

  const verifyAndEnable = async () => {
    if (!verificationCode) {
      toast({
        title: "Verification code required",
        description: "Please enter the verification code from your authenticator app.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      // In a real app, we would call an API to verify the code and enable 2FA
      // const response = await fetch("/api/user/2fa/verify", {
      //   method: "POST",
      //   headers: { "Content-Type": "application/json" },
      //   body: JSON.stringify({ code: verificationCode }),
      // })

      // For demo purposes, just simulate the API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Simulate successful verification if code is "123456"
      if (verificationCode === "123456") {
        setEnabled(true)
        setShowSetup(false)
        toast({
          title: "Two-factor authentication enabled",
          description: "Your account is now more secure.",
        })
      } else {
        toast({
          title: "Invalid verification code",
          description: "Please try again with the correct code from your authenticator app.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error verifying 2FA code:", error)
      toast({
        title: "Error enabling two-factor authentication",
        description: "Please try again later.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const cancelSetup = () => {
    setShowSetup(false)
    setQrCode(null)
    setSecret(null)
    setVerificationCode("")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Shield className="mr-2 h-5 w-5" />
          Two-Factor Authentication
        </CardTitle>
        <CardDescription>
          Add an extra layer of security to your account by enabling two-factor authentication.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!showSetup ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {enabled ? (
                <ShieldCheck className="h-8 w-8 text-green-500" />
              ) : (
                <ShieldAlert className="h-8 w-8 text-yellow-500" />
              )}
              <div>
                <p className="font-medium">
                  {enabled ? "Two-factor authentication is enabled" : "Two-factor authentication is disabled"}
                </p>
                <p className="text-sm text-muted-foreground">
                  {enabled
                    ? "Your account is protected with an authenticator app."
                    : "We recommend enabling 2FA for better security."}
                </p>
              </div>
            </div>
            <Switch
              checked={enabled}
              onCheckedChange={handleToggle}
              disabled={loading}
              aria-label="Toggle two-factor authentication"
            />
          </div>
        ) : (
          <div className="space-y-6">
            <div className="space-y-2">
              <h3 className="text-lg font-medium">Set up two-factor authentication</h3>
              <p className="text-sm text-muted-foreground">
                Use an authenticator app like Google Authenticator, Authy, or Microsoft Authenticator to scan the QR
                code below.
              </p>
            </div>

            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <>
                {qrCode && (
                  <div className="flex flex-col items-center space-y-4">
                    <div className="border p-2 rounded-lg">
                      <img
                        src={qrCode || "/placeholder.svg"}
                        alt="QR Code for two-factor authentication"
                        width={200}
                        height={200}
                      />
                    </div>
                    {secret && (
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-1">
                          If you can't scan the QR code, enter this code manually:
                        </p>
                        <code className="bg-muted px-2 py-1 rounded text-sm font-mono">{secret}</code>
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="verification-code">Verification Code</Label>
                  <Input
                    id="verification-code"
                    placeholder="Enter 6-digit code"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value)}
                    maxLength={6}
                  />
                  <p className="text-xs text-muted-foreground">
                    Enter the 6-digit code from your authenticator app to verify and enable 2FA.
                  </p>
                </div>
              </>
            )}
          </div>
        )}
      </CardContent>
      {showSetup && (
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={cancelSetup} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={verifyAndEnable} disabled={loading || !verificationCode}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifying...
              </>
            ) : (
              "Verify and Enable"
            )}
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}

