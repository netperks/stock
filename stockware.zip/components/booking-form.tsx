"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { toast } from "@/components/ui/use-toast"
import { format, differenceInDays, addDays } from "date-fns"
import { CalendarIcon, Loader2 } from "lucide-react"
import { razorpayConfig } from "@/lib/razorpay"

interface BookingFormProps {
  warehouseId: string
  price: number
  warehouseName: string
}

export function BookingForm({ warehouseId, price, warehouseName }: BookingFormProps) {
  const [startDate, setStartDate] = useState<Date | undefined>(undefined)
  const [endDate, setEndDate] = useState<Date | undefined>(undefined)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { data: session, status } = useSession()
  const router = useRouter()

  // Calculate total price
  const days = startDate && endDate ? differenceInDays(endDate, startDate) + 1 : 0
  const totalPrice = days * price

  const handleBooking = async () => {
    if (status !== "authenticated") {
      toast({
        title: "Please sign in to book a warehouse",
        description: "You need to be signed in to book a warehouse.",
        variant: "destructive",
      })
      router.push(`/auth/signin?callbackUrl=/warehouses/${warehouseId}`)
      return
    }

    if (!startDate || !endDate) {
      toast({
        title: "Please select both start and end dates",
        description: "Both dates are required to proceed with booking.",
        variant: "destructive",
      })
      return
    }

    if (startDate > endDate) {
      toast({
        title: "Invalid date range",
        description: "End date must be after start date.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Create Razorpay order
      const orderResponse = await fetch("/api/create-razorpay-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          warehouseId,
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString(),
          amount: totalPrice * 100, // Razorpay expects amount in paise
          days,
        }),
      })

      if (!orderResponse.ok) {
        throw new Error("Failed to create order")
      }

      const { orderId } = await orderResponse.json()

      // Initialize Razorpay
      const options = {
        key: razorpayConfig.key_id,
        amount: totalPrice * 100,
        currency: "INR",
        name: "Stockware",
        description: `Booking for ${warehouseName}`,
        order_id: orderId,
        handler: async (response: any) => {
          // Verify payment on server
          const verifyResponse = await fetch("/api/verify-payment", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_order_id: response.razorpay_order_id,
              razorpay_signature: response.razorpay_signature,
              warehouseId,
              startDate: startDate.toISOString(),
              endDate: endDate.toISOString(),
              days,
            }),
          })

          if (verifyResponse.ok) {
            const { bookingId } = await verifyResponse.json()
            toast({
              title: "Booking confirmed!",
              description: "Your warehouse has been booked successfully.",
            })
            router.push(`/dashboard/bookings/${bookingId}`)
          } else {
            toast({
              title: "Payment verification failed",
              description: "Please contact support if your payment was deducted.",
              variant: "destructive",
            })
          }
        },
        prefill: {
          name: session?.user?.name || "",
          email: session?.user?.email || "",
        },
        theme: {
          color: "#3B82F6",
        },
      }

      // @ts-ignore - Razorpay is loaded via script
      const razorpay = new window.Razorpay(options)
      razorpay.open()
    } catch (error) {
      console.error("Booking error:", error)
      toast({
        title: "Booking failed",
        description: "There was an error processing your booking. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Load Razorpay script
  useEffect(() => {
    const script = document.createElement("script")
    script.src = "https://checkout.razorpay.com/v1/checkout.js"
    script.async = true
    document.body.appendChild(script)

    return () => {
      document.body.removeChild(script)
    }
  }, [])

  return (
    <Card>
      <CardContent className="p-6">
        <div className="text-2xl font-bold mb-4">₹{price.toLocaleString()}/day</div>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label htmlFor="startDate" className="block text-sm font-medium">
                Start Date
              </label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal" id="startDate">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, "PPP") : <span>Select date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={(date) => {
                      setStartDate(date)
                      // If end date is not set or is before start date, set it to start date + 1 day
                      if (!endDate || (date && endDate < date)) {
                        setEndDate(date ? addDays(date, 1) : undefined)
                      }
                    }}
                    disabled={(date) => date < new Date()}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-2">
              <label htmlFor="endDate" className="block text-sm font-medium">
                End Date
              </label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal" id="endDate">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {endDate ? format(endDate, "PPP") : <span>Select date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={setEndDate}
                    disabled={(date) => date < (startDate || new Date())}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {days > 0 && (
            <div className="bg-muted p-3 rounded-md">
              <div className="flex justify-between text-sm">
                <span>Price per day:</span>
                <span>₹{price.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Number of days:</span>
                <span>{days}</span>
              </div>
              <div className="flex justify-between font-bold mt-2 pt-2 border-t border-border">
                <span>Total:</span>
                <span>₹{totalPrice.toLocaleString()}</span>
              </div>
            </div>
          )}

          <Button className="w-full" onClick={handleBooking} disabled={isSubmitting || !startDate || !endDate}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              "Book Now"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

