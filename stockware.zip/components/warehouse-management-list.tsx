import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Edit, Trash, Eye } from "lucide-react"
import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function WarehouseManagementList({ userId }: { userId: string }) {
  const client = await clientPromise
  const db = client.db("stockware")

  const warehouses = await db
    .collection("warehouses")
    .find({ ownerId: new ObjectId(userId) })
    .sort({ createdAt: -1 })
    .toArray()

  if (warehouses.length === 0) {
    return (
      <div className="text-center py-12 bg-muted rounded-lg">
        <h3 className="text-lg font-medium">No warehouses found</h3>
        <p className="text-muted-foreground mt-2">Add your first warehouse to start receiving bookings.</p>
        <Link href="/dashboard/warehouse-owner/add" className="mt-4 inline-block">
          <Button>Add Warehouse</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {warehouses.map((warehouse) => (
        <Card key={warehouse._id.toString()} className="overflow-hidden">
          <CardHeader className="p-0">
            <div className="relative h-48 w-full">
              <Image
                src={warehouse.imageUrl || "/placeholder.svg?height=200&width=300"}
                alt={warehouse.name}
                fill
                className="object-cover"
              />
              <div className="absolute top-2 right-2">
                <Badge>{warehouse.type.replace("_", " ")}</Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <h3 className="text-xl font-semibold mb-1">{warehouse.name}</h3>
            <p className="text-sm text-muted-foreground mb-2">{warehouse.location}</p>
            <p className="font-bold">₹{warehouse.price}/month</p>
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm text-muted-foreground">{warehouse.capacity} sq ft</span>
              <Badge variant="outline">{warehouse.status || "Available"}</Badge>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between p-4 pt-0 border-t">
            <Link href={`/warehouses/${warehouse._id}`}>
              <Button variant="outline" size="sm">
                <Eye className="h-4 w-4 mr-1" />
                View
              </Button>
            </Link>
            <div className="flex gap-2">
              <Link href={`/dashboard/warehouse-owner/edit/${warehouse._id}`}>
                <Button variant="outline" size="sm">
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
              </Link>
              <form action={`/api/warehouses/${warehouse._id}/delete`} method="POST">
                <Button variant="destructive" size="sm" type="submit">
                  <Trash className="h-4 w-4 mr-1" />
                  Delete
                </Button>
              </form>
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

